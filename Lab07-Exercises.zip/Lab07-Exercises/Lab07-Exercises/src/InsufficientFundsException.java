// Exercise 7.4: checked exception that carries useful details
public class InsufficientFundsException extends Exception {

    private final double requested;
    private final double available;

    public InsufficientFundsException(double requested, double available) {
        super(String.format("Insufficient funds: requested %.2f but only %.2f available", requested, available));
        this.requested = requested;
        this.available = available;
    }

    public double getShortfall() { return requested - available; }
}
