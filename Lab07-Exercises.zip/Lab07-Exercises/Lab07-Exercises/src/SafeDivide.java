import java.util.NoSuchElementException;
import java.util.Scanner;

// Exercise 7.1 (Basic): read two integers and divide them, handling BOTH
//   - non-numeric input        (NumberFormatException from Integer.parseInt)
//   - division by zero         (ArithmeticException from int division)
public class SafeDivide {

    // Prints the prompt, reads one line, and (when echo is true) shows what was typed,
    // so a scripted run produces a readable transcript.
    private static String ask(Scanner in, String prompt, boolean echo) {
        System.out.print(prompt);
        String line = in.nextLine();
        if (echo) System.out.println(line);
        return line;
    }

    public static void run(Scanner in, boolean echo) {
        while (true) {
            try {
                // Read BOTH answers first, then convert, so a bad first answer does not
                // leave the second prompt out of step with the input
                String first  = ask(in, "Enter the numerator: ", echo).trim();
                String second = ask(in, "Enter the denominator: ", echo).trim();
                int a = Integer.parseInt(first);            // throws NumberFormatException if not a whole number
                int b = Integer.parseInt(second);
                int quotient = a / b;                       // throws ArithmeticException when b == 0
                System.out.println(a + " / " + b + " = " + quotient + " remainder " + (a % b));
                return;                                     // success: stop asking
            } catch (NumberFormatException e) {
                System.out.println("  That is not a whole number. Let's start again.");
            } catch (ArithmeticException e) {
                System.out.println("  You cannot divide by zero. Let's start again.");
            } catch (NoSuchElementException e) {
                System.out.println();
                System.out.println("  No more input. Stopping.");
                return;
            }
        }
    }

    public static void main(String[] args) {
        run(new Scanner(System.in), false);
    }
}
