// Exercise 7.2 (Basic): access an array element and catch ArrayIndexOutOfBoundsException
public class ArrayAccess {

    // Returns the element, or -1 when the index is invalid.
    // (Using -1 as an error signal is only safe when -1 can never be a real value.)
    public static int getElement(int[] data, int index) {
        try {
            return data[index];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("  Invalid index " + index + " for an array of length " + data.length
                    + " (" + e.getMessage() + ")");
            return -1;
        }
    }

    public static void main(String[] args) {
        int[] data = {10, 20, 30};
        System.out.println("data[1]  = " + getElement(data, 1));
        System.out.println("data[10] = " + getElement(data, 10));
        System.out.println("data[-1] = " + getElement(data, -1));
        System.out.println("Program continues normally after the errors.");
    }
}
