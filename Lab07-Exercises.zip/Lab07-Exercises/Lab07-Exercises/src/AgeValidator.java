// Exercise 7.3
public class AgeValidator {

    // 'throws' is part of the method's contract: callers MUST handle or re-declare it
    public static void validateAge(int age) throws InvalidAgeException {
        if (age < 0 || age > 120) {
            throw new InvalidAgeException(age);
        }
    }

    public static void main(String[] args) {
        int[] ages = {25, -3, 130, 0, 120, 121};
        for (int age : ages) {
            try {
                validateAge(age);
                System.out.println(age + " -> valid");
            } catch (InvalidAgeException e) {
                System.out.println(age + " -> rejected: " + e.getMessage());
            }
        }

        // validateAge(50);   // COMPILE ERROR: unreported exception InvalidAgeException;
        //                    // must be caught or declared to be thrown
    }
}
