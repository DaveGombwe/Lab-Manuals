// Exercise 7.5 (Challenge): return inside try, print inside finally.
//
// PREDICTION (written BEFORE running):
//   tryReturn():   the return value (1) is worked out first, then finally RUNS and prints,
//                  and only then does the method actually return 1.
//                  So "finally block runs" is printed BEFORE "tryReturn returned 1".
//   changeInFinally(): x is 1 when "return x" is evaluated; that value is saved.
//                  Changing x to 99 in finally does NOT change the saved value: returns 1.
//   returnInFinally(): a return inside finally REPLACES the earlier return (and would even
//                  swallow an exception). It gives 2. This is legal but a bad habit.
public class FinallyDemo {

    static int tryReturn() {
        try {
            System.out.println("  in try: about to return 1");
            return 1;
        } finally {
            System.out.println("  in finally: this still runs");
        }
    }

    static int changeInFinally() {
        int x = 1;
        try {
            return x;                 // the value 1 is copied aside here
        } finally {
            x = 99;                   // too late to affect the returned value
            System.out.println("  in finally: x is now " + x);
        }
    }

    @SuppressWarnings("finally")
    static int returnInFinally() {
        try {
            return 1;
        } finally {
            return 2;                 // overrides the return in try
        }
    }

    public static void main(String[] args) {
        System.out.println("tryReturn returned " + tryReturn());
        System.out.println("changeInFinally returned " + changeInFinally());
        System.out.println("returnInFinally returned " + returnInFinally());
    }
}
