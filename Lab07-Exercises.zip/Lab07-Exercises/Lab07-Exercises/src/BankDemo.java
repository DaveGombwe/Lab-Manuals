// Exercise 7.4
public class BankDemo {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount("ACC-001", "Tendai", 500.00);
        System.out.println(acc);

        try {
            acc.withdraw(200.00);
            System.out.println("Withdrew 200.00 -> " + acc);
            acc.withdraw(5000.00);                         // too much
            System.out.println("This line is skipped when the line above throws");
        } catch (InsufficientFundsException e) {
            System.out.println("Rejected: " + e.getMessage());
            System.out.printf("Shortfall: %.2f%n", e.getShortfall());
        }
        System.out.println(acc);                           // state unchanged by the failed withdrawal

        // The compiler now FORCES every caller to decide; with the old boolean it was easy to forget:
        //     acc.withdraw(5000);    // COMPILE ERROR: unreported exception InsufficientFundsException
    }
}
