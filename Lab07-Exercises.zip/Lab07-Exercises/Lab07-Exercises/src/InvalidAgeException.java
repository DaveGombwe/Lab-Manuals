// Exercise 7.3 (Intermediate): a CHECKED custom exception (extends Exception, not RuntimeException)
public class InvalidAgeException extends Exception {

    private final int age;

    public InvalidAgeException(int age) {
        super("Age must be between 0 and 120, but was " + age);
        this.age = age;
    }

    public int getAge() { return age; }
}
