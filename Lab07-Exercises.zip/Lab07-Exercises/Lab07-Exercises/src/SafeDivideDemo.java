import java.util.Scanner;

// Exercise 7.1: runs SafeDivide with SCRIPTED input, so you can see every case without typing
public class SafeDivideDemo {
    public static void main(String[] args) {
        String script =
              "abc\n5\n"      // attempt 1: "abc" is not a number
            + "10\n0\n"       // attempt 2: divide by zero
            + "10\n3\n";      // attempt 3: valid
        SafeDivide.run(new Scanner(script), true);
    }
}
