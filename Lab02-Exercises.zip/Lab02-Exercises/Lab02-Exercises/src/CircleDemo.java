// Exercises 2.1 and 2.2
public class CircleDemo {
    public static void main(String[] args) {
        System.out.println("Circles before: " + Circle.getCount());   // no object needed

        Circle c1 = new Circle(2.5);
        Circle c2 = new Circle();        // radius defaults to 1.0
        Circle c3 = new Circle(4);

        c1.display();
        c2.display();
        c3.display();

        System.out.println("Circles after: " + Circle.getCount());
    }
}
