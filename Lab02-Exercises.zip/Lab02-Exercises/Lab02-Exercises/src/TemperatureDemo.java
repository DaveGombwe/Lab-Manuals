// Exercise 2.5
public class TemperatureDemo {
    public static void main(String[] args) {
        Temperature boiling  = Temperature.fromCelsius(100);
        Temperature freezing = Temperature.fromFahrenheit(32);
        Temperature body     = Temperature.fromCelsius(36.6);

        System.out.println("boiling : " + boiling);
        System.out.println("freezing: " + freezing);
        System.out.println("body    : " + body);

        // Temperature t = new Temperature(100);   // COMPILE ERROR: constructor is private
        //
        // Why not two overloaded constructors?
        //     Temperature(double celsius)
        //     Temperature(double fahrenheit)
        // Both have the signature (double), so Java rejects the second one: overloads must
        // differ in the TYPES or NUMBER of parameters, and parameter names do not count.
    }
}
