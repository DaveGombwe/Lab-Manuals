// Exercise 2.5 (Challenge): static factory methods and a private constructor
public class Temperature {

    private final double celsius;

    // EXPLAIN: private -> nobody outside can call 'new Temperature(...)'
    private Temperature(double celsius) {
        this.celsius = celsius;
    }

    // Static factory methods: the NAME says which unit the number is in
    public static Temperature fromCelsius(double degrees) {
        return new Temperature(degrees);
    }

    public static Temperature fromFahrenheit(double degrees) {
        return new Temperature((degrees - 32) * 5.0 / 9.0);
    }

    public double getCelsius() {
        return celsius;
    }

    public double getFahrenheit() {
        return celsius * 9.0 / 5.0 + 32;
    }

    @Override
    public String toString() {
        return String.format("%.1f C = %.1f F", getCelsius(), getFahrenheit());
    }
}
