// Exercise 2.4 (Intermediate): a class with TWO static blocks and TWO instance blocks.
//
// PREDICTION (written BEFORE running):
//   1. When the class is loaded (before main runs) BOTH static blocks run, once, in the
//      order they are written:      static block 1, static block 2
//   2. main then starts:            main starts
//   3. For EVERY new object, both instance blocks run first (in written order),
//      THEN the constructor body:   instance block 1, instance block 2, constructor
//   Two objects are created, so step 3 appears twice.
public class TwoBlocks {

    static { System.out.println("static block 1"); }

    { System.out.println("instance block 1"); }

    TwoBlocks() {
        System.out.println("constructor");
    }

    static { System.out.println("static block 2"); }

    { System.out.println("instance block 2"); }

    public static void main(String[] args) {
        System.out.println("main starts");
        new TwoBlocks();
        new TwoBlocks();
    }
}
