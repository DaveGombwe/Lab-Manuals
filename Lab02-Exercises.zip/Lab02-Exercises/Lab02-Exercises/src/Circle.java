// Exercises 2.1 (Basic) and 2.2 (Basic)
public class Circle {

    // Exercise 2.2: ONE counter shared by every Circle
    private static int count = 0;

    private double radius;

    // Exercise 2.1: constructor taking the radius
    public Circle(double radius) {
        this.radius = radius;      // EXPLAIN: this.radius = field, radius = parameter
        count++;                   // runs once per object created
    }

    // Exercise 2.1: no-argument constructor defaults the radius to 1.0
    public Circle() {
        this(1.0);                 // EXPLAIN: chaining; count++ happens inside the other constructor
    }

    // Exercise 2.2: static getter, called as Circle.getCount()
    public static int getCount() {
        return count;
    }

    public double getRadius() {
        return radius;
    }

    public double area() {
        return Math.PI * radius * radius;
    }

    public void display() {
        System.out.printf("Circle radius=%.2f area=%.2f%n", radius, area());
    }
}
