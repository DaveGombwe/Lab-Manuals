// Exercise 2.3 (Intermediate)
public class Employee {

    private static int nextId = 1;                       // shared counter: the next free id
    private static final String DEFAULT_DEPARTMENT = "Unassigned";
    private static final double DEFAULT_SALARY = 0.0;

    private final int employeeId;                        // assigned once, never changes
    private final String name;
    private final String department;
    private final double salary;

    // Constructor 1 (the "master" constructor): everything is set here
    public Employee(String name, String department, double salary) {
        this.employeeId = nextId++;        // EXPLAIN: take the current id, then increase the counter
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    // Constructor 2: name + department, default salary
    public Employee(String name, String department) {
        this(name, department, DEFAULT_SALARY);
    }

    // Constructor 3: name only, default department and salary
    public Employee(String name) {
        this(name, DEFAULT_DEPARTMENT);
    }

    // Copy constructor: same details, but a NEW employee record, so it gets a NEW id.
    // EXPLAIN: chaining through the master constructor guarantees the id is assigned exactly once.
    public Employee(Employee other) {
        this(other.name, other.department, other.salary);
    }

    public static int getTotalCreated() {
        return nextId - 1;
    }

    public void display() {
        System.out.printf("#%d %-6s | %-10s | %8.2f%n", employeeId, name, department, salary);
    }
}
