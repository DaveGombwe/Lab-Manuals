// Exercise 2.3: auto-incrementing id, three overloaded constructors, and a copy constructor
public class EmployeeDemo {
    public static void main(String[] args) {
        Employee e1 = new Employee("Chipo", "Finance", 2500.00);
        Employee e2 = new Employee("Farai", "IT");
        Employee e3 = new Employee("Rudo");
        Employee e4 = new Employee(e1);        // copy of Chipo, with its own id

        e1.display();
        e2.display();
        e3.display();
        e4.display();
        System.out.println("Total employees created: " + Employee.getTotalCreated());
        System.out.println("e1 == e4 ? " + (e1 == e4));
    }
}
