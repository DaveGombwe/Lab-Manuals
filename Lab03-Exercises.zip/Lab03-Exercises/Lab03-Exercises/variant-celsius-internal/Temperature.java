// VARIANT of Exercise 3.5: the internal unit is now CELSIUS.
// The public API is identical, so TemperatureDemo.java needs no change at all.
public class Temperature {

    private static final double ZERO_C_IN_K = 273.15;
    private static final double TOLERANCE = 1e-9;

    private final double celsius;      // <- the only real change: the private field

    private Temperature(double celsius) {
        if (celsius < -ZERO_C_IN_K - TOLERANCE) {
            throw new IllegalArgumentException(String.format("Below absolute zero: %.2f K is impossible", celsius + ZERO_C_IN_K));
        }
        this.celsius = Math.max(-ZERO_C_IN_K, celsius);
    }

    public static Temperature ofKelvin(double k)     { return new Temperature(k - ZERO_C_IN_K); }
    public static Temperature ofCelsius(double c)    { return new Temperature(c); }
    public static Temperature ofFahrenheit(double f) { return new Temperature((f - 32) * 5.0 / 9.0); }

    public double getKelvin()     { return celsius + ZERO_C_IN_K; }
    public double getCelsius()    { return celsius; }
    public double getFahrenheit() { return celsius * 9.0 / 5.0 + 32; }

    @Override
    public String toString() {
        return String.format("%.2f C | %.2f F | %.2f K", getCelsius(), getFahrenheit(), getKelvin());
    }
}
