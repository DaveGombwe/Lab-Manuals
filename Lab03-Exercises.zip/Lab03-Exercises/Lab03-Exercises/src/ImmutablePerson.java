import java.util.List;

// Exercise 3.4 (Intermediate). Each DESIGN comment explains one choice.

// DESIGN 1: the class is final, so no subclass can add mutable state or override a getter to cheat.
public final class ImmutablePerson {

    // DESIGN 2: every field is private and final; it is assigned once, in the constructor.
    private final String name;
    private final int age;
    private final List<String> hobbies;

    public ImmutablePerson(String name, int age, List<String> hobbies) {
        // DESIGN 3: validate in the constructor; there is no later chance to fix a bad object.
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name required");
        }
        if (age < 0) {
            throw new IllegalArgumentException("Age cannot be negative");
        }
        this.name = name.trim();
        this.age = age;
        // DESIGN 4: DEFENSIVE COPY on the way in. If we stored the caller's list, the caller could
        // still change it later and silently change our object. List.copyOf makes our own
        // unmodifiable list (and rejects null elements).
        this.hobbies = List.copyOf(hobbies);
    }

    // DESIGN 5: getters only, no setters.
    public String getName() { return name; }
    public int getAge()     { return age; }

    // DESIGN 6: it is safe to return the list itself because it is already unmodifiable
    // (a mutable list would need a copy on the way out too).
    public List<String> getHobbies() { return hobbies; }

    // DESIGN 7: "changes" create a NEW object and leave this one untouched.
    public ImmutablePerson withAge(int newAge) {
        return new ImmutablePerson(name, newAge, hobbies);
    }

    @Override
    public String toString() {
        return name + ", " + age + ", hobbies=" + hobbies;
    }
}
