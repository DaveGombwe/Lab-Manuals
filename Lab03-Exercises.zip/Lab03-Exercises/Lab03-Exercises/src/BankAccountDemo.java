import java.util.List;

// Exercise 3.3
public class BankAccountDemo {
    public static void main(String[] args) {
        BankAccount acc = new BankAccount("ACC-001", "Tendai", 500.00);
        acc.deposit(250.00);
        acc.withdraw(100.00);
        acc.withdraw(5000.00);                 // rejected, but still recorded

        System.out.println(acc);
        System.out.println("--- history ---");
        List<String> snapshot = acc.getTransactionHistory();
        for (String line : snapshot) {
            System.out.println(line);
        }

        // The returned list cannot be modified
        try {
            snapshot.add("DEPOSIT   1000000.00");
        } catch (UnsupportedOperationException e) {
            System.out.println("Tampering blocked: history is read-only");
        }

        // It is a COPY: a transaction made later does not appear in the snapshot we already hold
        acc.deposit(10.00);
        System.out.println("Snapshot size: " + snapshot.size());
        System.out.println("Fresh history size: " + acc.getTransactionHistory().size());
    }
}
