// Exercise 3.5 (Challenge): the value is stored in KELVIN internally.
// Callers only see getCelsius(), getFahrenheit(), getKelvin(), so the storage unit is a private detail.
public class Temperature {

    private static final double ZERO_C_IN_K = 273.15;
    private static final double TOLERANCE = 1e-9;     // absorbs floating-point rounding at 0 K

    // EXPLAIN: the ONE private field. Changing its unit later touches only this class.
    private final double kelvin;

    private Temperature(double kelvin) {
        if (kelvin < -TOLERANCE) {
            throw new IllegalArgumentException(String.format("Below absolute zero: %.2f K is impossible", kelvin));
        }
        this.kelvin = Math.max(0.0, kelvin);
    }

    public static Temperature ofKelvin(double k)     { return new Temperature(k); }
    public static Temperature ofCelsius(double c)    { return new Temperature(c + ZERO_C_IN_K); }
    public static Temperature ofFahrenheit(double f) { return new Temperature((f - 32) * 5.0 / 9.0 + ZERO_C_IN_K); }

    public double getKelvin()     { return kelvin; }
    public double getCelsius()    { return kelvin - ZERO_C_IN_K; }
    public double getFahrenheit() { return getCelsius() * 9.0 / 5.0 + 32; }

    @Override
    public String toString() {
        return String.format("%.2f C | %.2f F | %.2f K", getCelsius(), getFahrenheit(), getKelvin());
    }
}
