import java.util.ArrayList;
import java.util.List;

// Exercise 3.3 (Intermediate): BankAccount from Program 3.1, extended with a transaction history
public class BankAccount {

    private final String accountNumber;
    private String ownerName;
    private double balance;

    // NEW: the history is private and final; nobody outside can touch the real list
    private final List<String> history = new ArrayList<>();

    public BankAccount(String accountNumber, String ownerName, double openingBalance) {
        if (openingBalance < 0) {
            throw new IllegalArgumentException("Opening balance cannot be negative");
        }
        this.accountNumber = accountNumber;
        setOwnerName(ownerName);
        this.balance = openingBalance;
        history.add(String.format("OPEN      %.2f", openingBalance));
    }

    public String getAccountNumber() { return accountNumber; }
    public String getOwnerName()     { return ownerName; }
    public double getBalance()       { return balance; }

    public void setOwnerName(String ownerName) {
        if (ownerName == null || ownerName.isBlank()) {
            throw new IllegalArgumentException("Owner name required");
        }
        this.ownerName = ownerName.trim();
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Deposit must be positive");
        }
        balance += amount;
        history.add(String.format("DEPOSIT   %.2f", amount));
    }

    public boolean withdraw(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Withdrawal must be positive");
        }
        if (amount > balance) {
            history.add(String.format("REJECTED  %.2f (insufficient funds)", amount));
            return false;
        }
        balance -= amount;
        history.add(String.format("WITHDRAW  %.2f", amount));
        return true;
    }

    // EXPLAIN: List.copyOf returns an UNMODIFIABLE COPY (a snapshot), so the caller can neither
    // change our list nor see later transactions appear inside the list they already hold.
    public List<String> getTransactionHistory() {
        return List.copyOf(history);
    }

    @Override
    public String toString() {
        return String.format("%s [%s] balance: %.2f", accountNumber, ownerName, balance);
    }
}
