// Exercises 3.1 and 3.2
public class StudentDemo {
    public static void main(String[] args) {
        Student[] students = {
            new Student("Tariro", 95),
            new Student("Farai", 72),
            new Student("Rudo", 61),
            new Student("Tendai", 40)
        };
        for (Student s : students) {
            System.out.println(s);
        }

        // Changing marks: the grade follows automatically because it is derived
        students[3].setMarks(85);
        System.out.println("After resit: " + students[3]);

        // Invalid values are rejected by the setter and the object keeps its old state
        try {
            students[0].setMarks(150);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
        try {
            students[0].setMarks(-5);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
        System.out.println("Unchanged: " + students[0]);

        // The constructor enforces the same rule
        try {
            new Student("Nyasha", 101);
        } catch (IllegalArgumentException e) {
            System.out.println("Constructor rejected: " + e.getMessage());
        }

        // students[0].marks = 500;   // COMPILE ERROR: marks has private access
    }
}
