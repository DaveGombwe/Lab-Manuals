import java.util.ArrayList;
import java.util.List;

// Exercise 3.4
public class ImmutablePersonDemo {
    public static void main(String[] args) {
        List<String> hobbies = new ArrayList<>();
        hobbies.add("chess");
        hobbies.add("football");

        ImmutablePerson p = new ImmutablePerson("Chipo", 20, hobbies);
        System.out.println(p);

        // 1. Changing the ORIGINAL list afterwards does not affect the person (defensive copy)
        hobbies.add("hacking");
        System.out.println("After changing the caller's list: " + p);

        // 2. The list we get back cannot be modified
        try {
            p.getHobbies().add("hacking");
        } catch (UnsupportedOperationException e) {
            System.out.println("getHobbies() is read-only");
        }

        // 3. A "change" produces a new object; the old one is untouched
        ImmutablePerson older = p.withAge(21);
        System.out.println("older: " + older);
        System.out.println("p    : " + p);
        System.out.println("same object? " + (p == older));

        // p.age = 99;                          // COMPILE ERROR: private and final
        // class Hacker extends ImmutablePerson // COMPILE ERROR: cannot inherit from final class
    }
}
