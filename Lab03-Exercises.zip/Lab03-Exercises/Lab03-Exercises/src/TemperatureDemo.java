// Exercise 3.5. This file is NEVER edited when the internal unit changes (see variant-celsius-internal).
public class TemperatureDemo {
    public static void main(String[] args) {
        System.out.println("25 C      -> " + Temperature.ofCelsius(25));
        System.out.println("212 F     -> " + Temperature.ofFahrenheit(212));
        System.out.println("0 K       -> " + Temperature.ofKelvin(0));
        System.out.println("-273.15 C -> " + Temperature.ofCelsius(-273.15) + "   (absolute zero is allowed)");

        try {
            Temperature.ofCelsius(-300);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
        try {
            Temperature.ofKelvin(-1);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
    }
}
