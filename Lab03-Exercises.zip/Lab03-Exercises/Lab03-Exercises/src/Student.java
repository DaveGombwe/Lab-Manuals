// Exercises 3.1 (Basic) and 3.2 (Basic)
public class Student {

    // EXPLAIN: private -> only this class can touch the data
    private String name;
    private int marks;          // invariant: always between 0 and 100

    // The constructor reuses the setters, so the rules are written ONCE and applied everywhere
    public Student(String name, int marks) {
        setName(name);
        setMarks(marks);
    }

    public String getName() { return name; }
    public int getMarks()   { return marks; }

    public void setName(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Name required");
        }
        this.name = name.trim();
    }

    // Exercise 3.1: reject invalid marks
    public void setMarks(int marks) {
        if (marks < 0 || marks > 100) {
            throw new IllegalArgumentException("Marks must be between 0 and 100, got " + marks);
        }
        this.marks = marks;
    }

    // Exercise 3.2: the grade is DERIVED from marks, so it is never stored and can never go stale.
    // Scale used: A 80-100, B 70-79, C 60-69, F below 60.
    public String getGrade() {
        if (marks >= 80) return "A";
        if (marks >= 70) return "B";
        if (marks >= 60) return "C";
        return "F";
    }

    @Override
    public String toString() {
        return name + " (" + marks + ") grade " + getGrade();
    }
}
