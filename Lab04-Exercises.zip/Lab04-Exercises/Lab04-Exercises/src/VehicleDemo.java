// Exercise 4.3: trace the order of constructor calls
public class VehicleDemo {
    public static void main(String[] args) {
        System.out.println("Creating a plain Car:");
        new Car("Toyota", 5);

        System.out.println();
        System.out.println("Creating an ElectricCar:");
        ElectricCar e = new ElectricCar("Tesla", 4, 75);
        System.out.println("Object ready: ");
        e.describe();
        // Constructors run from the TOP of the hierarchy down: Vehicle, then Car, then ElectricCar.
    }
}
