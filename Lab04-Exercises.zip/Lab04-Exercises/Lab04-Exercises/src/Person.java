// Exercises 4.1 (Basic) and 4.2 (Basic): the SUPERCLASS holding the shared code
public class Person {

    private final String name;
    private final int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() { return name; }
    public int getAge()     { return age; }

    // EXPLAIN: written ONCE here; Student and Teacher inherit it without copying a line
    public void display() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}
