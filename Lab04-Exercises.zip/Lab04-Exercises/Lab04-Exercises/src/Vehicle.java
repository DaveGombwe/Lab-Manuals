// Exercise 4.3 (Intermediate): level 1 of a multilevel hierarchy
public class Vehicle {
    protected final String brand;

    public Vehicle(String brand) {
        this.brand = brand;
        System.out.println("1. Vehicle constructor: " + brand);
    }
}
