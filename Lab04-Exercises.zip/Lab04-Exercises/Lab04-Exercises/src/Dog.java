// Exercise 4.4: the FIXED Dog. It must call super(name) explicitly.
// The version without that call is in ../does-not-compile/Dog_FAILS.java.txt
public class Dog extends Animal {

    public Dog(String name) {
        super(name);       // without this line javac inserts super() and fails
    }

    @Override
    public void speak() {
        System.out.println(name + " says Woof");
    }
}
