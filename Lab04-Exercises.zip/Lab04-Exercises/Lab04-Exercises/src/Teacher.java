// Exercise 4.2: Teacher IS-A Person too, and adds a subject
public class Teacher extends Person {

    private final String subject;

    public Teacher(String name, int age, String subject) {
        super(name, age);
        this.subject = subject;
    }

    public String getSubject() { return subject; }
}
