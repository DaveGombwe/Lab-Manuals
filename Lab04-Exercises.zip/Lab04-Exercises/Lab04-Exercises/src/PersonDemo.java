// Exercises 4.1 and 4.2
public class PersonDemo {
    public static void main(String[] args) {
        Person p  = new Person("Gift", 45);
        Student s = new Student("Tariro", 19, "Computer Science");
        Teacher t = new Teacher("Mr Moyo", 38, "Mathematics");

        // Exercise 4.1: the SAME inherited display() on a Person and on a Student
        p.display();
        s.display();
        System.out.println("   course : " + s.getCourse());

        // Exercise 4.2: a second subclass reuses the very same code
        t.display();
        System.out.println("   subject: " + t.getSubject());

        // Both subclasses can be treated as Persons because each IS-A Person
        System.out.println("--- shared Person code ---");
        Person[] everyone = {p, s, t};
        for (Person x : everyone) {
            x.display();          // one method, written once in Person
        }
    }
}
