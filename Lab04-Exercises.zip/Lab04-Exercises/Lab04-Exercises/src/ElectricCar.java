// Exercise 4.3: level 3 (ElectricCar extends Car extends Vehicle)
public class ElectricCar extends Car {
    private final int batteryKwh;

    public ElectricCar(String brand, int doors, int batteryKwh) {
        super(brand, doors);       // Car's constructor (which calls Vehicle's) runs first
        this.batteryKwh = batteryKwh;
        System.out.println("3. ElectricCar constructor: " + batteryKwh + " kWh battery");
    }

    public void describe() {
        System.out.println(brand + ", " + doors + " doors, " + batteryKwh + " kWh");
    }
}
