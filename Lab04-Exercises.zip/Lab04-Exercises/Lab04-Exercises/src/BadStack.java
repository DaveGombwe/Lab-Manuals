import java.util.ArrayList;

// Exercise 4.5 (Challenge), BEFORE: the flawed design "Stack IS-A ArrayList"
public class BadStack extends ArrayList<String> {

    public void push(String item) {
        add(item);
    }

    public String pop() {
        return remove(size() - 1);
    }

    public String peek() {
        return get(size() - 1);
    }
}
