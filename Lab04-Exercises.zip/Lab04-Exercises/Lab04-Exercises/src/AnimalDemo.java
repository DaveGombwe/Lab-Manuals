// Exercise 4.4 (the working version)
public class AnimalDemo {
    public static void main(String[] args) {
        Animal a = new Animal("Generic animal");
        Dog d = new Dog("Rex");
        a.speak();
        d.speak();
    }
}
