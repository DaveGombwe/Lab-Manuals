// Exercise 4.1: Student IS-A Person, and adds a course
public class Student extends Person {

    private final String course;

    public Student(String name, int age, String course) {
        super(name, age);          // EXPLAIN: runs Person's constructor first
        this.course = course;
    }

    public String getCourse() { return course; }
}
