// Exercise 4.5: what the inheritance version wrongly exposes
public class StackDemo {
    public static void main(String[] args) {
        System.out.println("=== BadStack (extends ArrayList) ===");
        BadStack bad = new BadStack();
        bad.push("A");
        bad.push("B");
        bad.push("C");

        // None of these are stack operations, yet all of them compile and run:
        bad.add(0, "INTRUDER");          // inserts at the BOTTOM of the stack
        bad.remove(1);                   // removes from the MIDDLE (removes "A")
        System.out.println("get(0) peeks at the bottom: " + bad.get(0));
        System.out.println("contents now: " + bad);
        System.out.println("pop order: " + bad.pop() + ", " + bad.pop() + ", " + bad.pop());
        bad.push("X");
        bad.clear();                     // wipes everything in one call
        System.out.println("after clear(), size = " + bad.size());

        System.out.println();
        System.out.println("=== GoodStack (has-a ArrayList) ===");
        GoodStack good = new GoodStack();
        good.push("A");
        good.push("B");
        good.push("C");
        System.out.println("peek: " + good.peek());
        System.out.println("pop order: " + good.pop() + ", " + good.pop() + ", " + good.pop());
        System.out.println("empty? " + good.isEmpty());

        // good.add(0, "INTRUDER");   // COMPILE ERROR: GoodStack has no add(int, String)
        // good.clear();              // COMPILE ERROR: GoodStack has no clear()

        try {
            good.pop();
        } catch (IllegalStateException e) {
            System.out.println("pop on empty: " + e.getMessage());
        }
    }
}
