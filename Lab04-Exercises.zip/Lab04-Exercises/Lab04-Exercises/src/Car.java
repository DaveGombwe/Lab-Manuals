// Exercise 4.3: level 2 (Car extends Vehicle)
public class Car extends Vehicle {
    protected final int doors;

    public Car(String brand, int doors) {
        super(brand);              // Vehicle's constructor runs BEFORE the next line
        this.doors = doors;
        System.out.println("2. Car constructor: " + doors + " doors");
    }
}
