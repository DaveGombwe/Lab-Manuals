import java.util.ArrayList;

// Exercise 4.5 (Challenge), AFTER: "Stack HAS-A list" (composition)
public class GoodStack {

    // EXPLAIN: private -> the list is an implementation detail nobody outside can reach
    private final ArrayList<String> items = new ArrayList<>();

    public void push(String item) {
        items.add(item);
    }

    public String pop() {
        if (items.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return items.remove(items.size() - 1);
    }

    public String peek() {
        if (items.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return items.get(items.size() - 1);
    }

    public boolean isEmpty() { return items.isEmpty(); }
    public int size()        { return items.size(); }
}
