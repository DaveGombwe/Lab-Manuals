// Exercise 4.4 (Intermediate): Animal has ONLY a constructor that needs a name
public class Animal {
    protected final String name;

    public Animal(String name) {
        this.name = name;
    }

    public void speak() {
        System.out.println(name + " makes a sound");
    }
}
