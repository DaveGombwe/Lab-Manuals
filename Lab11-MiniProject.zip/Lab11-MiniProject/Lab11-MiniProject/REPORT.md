# Mini-Project Report: Library Management System

**Course:** Object-Oriented Programming in Java, Lab 11
**Team members:** _(add names and student numbers)_
**Language / tools:** Java 17+ (developed and tested on JDK 21), VS Code

## 1. Overview

A console application that manages a small library. Staff can add books and DVDs, register members, lend and
take back items, list overdue items and search titles. Each member may hold at most **3** loans, books are lent
for **21** days and DVDs for **7**. All data is saved to CSV files on exit and reloaded at start-up.

## 2. Class diagram

```mermaid
classDiagram
    class Borrowable {
        <<interface>>
        +borrow(Member) void
        +giveBack() void
    }
    class LibraryItem {
        <<abstract>>
        -String id
        -String title
        -boolean available
        +loanPeriodDays() int
        +typeName() String
        +extraInfo() String
    }
    class Book {
        -String author
        +loanPeriodDays() int
    }
    class Dvd {
        -int minutes
        +loanPeriodDays() int
    }
    class Member {
        -String id
        -String name
        +ensureCanBorrow() void
    }
    class Loan {
        -LocalDate borrowedOn
        -LocalDate dueOn
        +isOverdue(LocalDate) boolean
    }
    class Library {
        -Map items
        -Map members
        +borrow() Loan
        +giveBack() Loan
        +listOverdue() List
        +searchByTitle() List
    }
    class LibraryItemFactory {
        +create() LibraryItem
    }
    class LibraryStorage {
        +save(Library) void
        +load() Library
    }
    class ItemNotAvailableException
    class MemberLimitExceededException
    Borrowable <|.. LibraryItem
    LibraryItem <|-- Book
    LibraryItem <|-- Dvd
    Library o-- LibraryItem : items map
    Library o-- Member : members map
    Member o-- Loan : at most 3
    Loan --> LibraryItem
    Loan --> Member
    LibraryItemFactory ..> Book : creates
    LibraryItemFactory ..> Dvd : creates
    LibraryStorage ..> Library : saves and loads
    Library ..> ItemNotAvailableException : throws
    Library ..> MemberLimitExceededException : throws
```

_(The diagram renders on GitHub and in VS Code with a Mermaid preview extension. In plain words: `LibraryItem` implements
`Borrowable`; `Book` and `Dvd` extend `LibraryItem`; `Library` owns maps of items and members; each `Member` holds up to three
`Loan`s; each `Loan` links one `Member` to one `LibraryItem`.)_

## 3. Requirements and where they are met

| Requirement | Where |
| --- | --- |
| `Book`, `Member`, `Loan` with private fields, validation and `toString` | `Book.java`, `Member.java`, `Loan.java`: private final fields, constructors reject blank ids/names and bad values, every class overrides `toString` |
| Abstract `LibraryItem` (title, id) with `Book` and `Dvd` each defining `loanPeriodDays()` | `LibraryItem.java`, `Book.java` (21 days), `Dvd.java` (7 days) |
| `Borrowable` interface with `borrow(Member)` and `giveBack()` | `Borrowable.java`, implemented once in `LibraryItem` |
| Custom exceptions `ItemNotAvailableException`, `MemberLimitExceededException` (max 3) | Two checked exceptions; `Member.MAX_LOANS = 3`; thrown from `Library.borrow` |
| Items and members in `Map<String, ...>` keyed by id | `Library.items`, `Library.members` (`LinkedHashMap`) |
| Persist to CSV on exit, reload on start | `LibraryStorage` writes `items.csv`, `members.csv`, `loans.csv`; `LibraryApp` loads on start and saves on exit (including when input ends) |
| Menu: add item, register member, borrow, return, list overdue, search by title (streams) | `LibraryApp.java`; overdue and search use streams in `Library.java` |

## 4. How the OOP concepts are used

| Concept | Evidence |
| --- | --- |
| **Encapsulation** | All fields private. `Member.getLoans()` returns an unmodifiable copy, so the 3-loan rule cannot be bypassed; only `Library` (same package) can add or remove loans. |
| **Inheritance** | `Book` and `Dvd` extend `LibraryItem` and reuse its id, title and borrow logic. |
| **Abstraction** | `LibraryItem` is abstract with abstract `loanPeriodDays()`, `typeName()`, `extraInfo()`. |
| **Interface** | `Borrowable` describes the lending capability separately from the class hierarchy. |
| **Polymorphism** | `Loan` computes its due date with `item.loanPeriodDays()` without knowing whether the item is a book or a DVD (the demo shows 21 vs 7). |
| **Exceptions** | Business-rule failures are checked custom exceptions; bad ids or values are `IllegalArgumentException`. The menu catches each and keeps running. `Library.borrow` checks every rule *before* changing any state, so a failed borrow leaves nothing half-done. |
| **Collections and streams** | `Map`s for lookup by id; `listOverdue` (filter, sorted by due date) and `searchByTitle` (case-insensitive filter, sorted by title) are stream pipelines. |
| **File I/O** | `LibraryStorage` with `java.nio.file`; `Csv` quotes fields containing commas, so a title such as "Clean Code, 2nd edition" survives a save and reload. Reloading replays each saved loan through `Library.borrow`, which rebuilds the links and re-checks every rule. |
| **Design patterns** | **Factory**: `LibraryItemFactory.create(type, ...)` is the only place that chooses `Book` or `Dvd`, used by both the menu and the CSV loader. Programs 11.1 (Singleton, Factory) and 11.2 (Strategy, Observer) from the lab are included unchanged. |

## 5. Test evidence

### 5.1 Scripted demonstration (`LibraryDemo`)

```
=== 1. Add items (Factory) and register members ===
  [B1] BOOK "Effective Java" (Joshua Bloch), 21-day loan, available
  [B2] BOOK "Clean Code, 2nd edition" (Robert Martin), 21-day loan, available
  [B3] BOOK "Java: The Complete Reference" (Herbert Schildt), 21-day loan, available
  [D1] DVD  "The Matrix" (136), 7-day loan, available
  [D2] DVD  "Inception" (148), 7-day loan, available
  [M1] Tariro (0/3 loans)
  [M2] Farai (0/3 loans)

=== 2. Polymorphism: same call, different loan period ===
  BOOK B1 -> loanPeriodDays() = 21
  BOOK B2 -> loanPeriodDays() = 21
  BOOK B3 -> loanPeriodDays() = 21
  DVD D1 -> loanPeriodDays() = 7
  DVD D2 -> loanPeriodDays() = 7

=== 3. Borrow (Tariro borrows 3 items on 2026-10-01) ===
  "Effective Java" borrowed by Tariro on 2026-10-01, due 2026-10-22
  "The Matrix" borrowed by Tariro on 2026-10-01, due 2026-10-08
  "Clean Code, 2nd edition" borrowed by Tariro on 2026-10-01, due 2026-10-22

=== 4. Custom exceptions ===
  MemberLimitExceededException: Member M1 already has the maximum of 3 loans
  ItemNotAvailableException: Item B1 ("Effective Java") is not available
  IllegalArgumentException: No member with id M9
  Farai borrows Inception on 2026-10-05: "Inception" borrowed by Farai on 2026-10-05, due 2026-10-12

=== 5. Overdue items as of 2026-10-15 (stream: filter + sort by due date) ===
  "The Matrix" borrowed by Tariro on 2026-10-01, due 2026-10-08  -> 7 days overdue
  "Inception" borrowed by Farai on 2026-10-05, due 2026-10-12  -> 3 days overdue

=== 6. Search by title (stream: filter + sort), text = "java" ===
  [B1] BOOK "Effective Java" (Joshua Bloch), 21-day loan, on loan to Tariro
  [B3] BOOK "Java: The Complete Reference" (Herbert Schildt), 21-day loan, available

=== 7. Return The Matrix on 2026-10-15 ===
  Returned "The Matrix", 7 days overdue
  Overdue now:
    "Inception" borrowed by Farai on 2026-10-05, due 2026-10-12

=== 8. Persistence: save to CSV, then reload into a brand-new Library ===
  Saved items.csv, members.csv and loans.csv to library-demo-data/
  Reloaded 5 items, 2 members, 3 active loans
    [B1] BOOK "Effective Java" (Joshua Bloch), 21-day loan, on loan to Tariro
    [B2] BOOK "Clean Code, 2nd edition" (Robert Martin), 21-day loan, on loan to Tariro
    [B3] BOOK "Java: The Complete Reference" (Herbert Schildt), 21-day loan, available
    [D1] DVD  "The Matrix" (136), 7-day loan, available
    [D2] DVD  "Inception" (148), 7-day loan, on loan to Farai
  Overdue after reload (as of 2026-10-15):
    "Inception" borrowed by Farai on 2026-10-05, due 2026-10-12
  Title with a comma survived the CSV round trip: Clean Code, 2nd edition
```

### 5.2 Interactive menu and persistence (`LibraryApp`)

The menu application was exercised with real keyboard-style input over **two separate runs**:

* **Run 1** (started with no data): added a book and a DVD, registered a member, borrowed both items, tried an unknown item
  (`Error: No item with id NOPE`) and an unknown member (`Error: No member with id M2`), searched for "java", moved the date to
  2026-12-25 and listed overdue items (68 and 54 days), then chose 0 to save.
* **Run 2** (a fresh JVM): started with `Loaded 2 items, 1 members, 2 active loans`, listed the same data, returned an item
  (`Returned "Toy Story" (68 days overdue)`), typed invalid options (`Unknown option: abc`), and when the input ended it
  still saved cleanly.

Files written by the application:

```
items.csv    BOOK,B10,Head First Java,Kathy Sierra
             DVD,D10,Toy Story,81
members.csv  M1,Tariro
loans.csv    B10,M1,2026-10-11
```

### 5.3 Pattern programs from the lab

Program 11.1 (`SingletonFactoryDemo`) and Program 11.2 (`StrategyObserverDemo`) produce exactly the output printed in the manual:

```
Same instance? true -> Example University
Email: Lab 11 is open
SMS: Lab 11 is open

Regular: 200.0
Student: 180.0
Student portal: OOP = 72
Student portal: Databases = 45
Advisor alert: Databases failed
```

## 6. Marking-guide self-check

| Criterion | Marks | Where it is addressed |
| --- | --- | --- |
| Class design: encapsulation, inheritance, interface, abstraction | 25 | Section 4; `LibraryItem`, `Book`, `Dvd`, `Borrowable`, `Member`, `Loan` |
| Polymorphism demonstrated meaningfully | 10 | `loanPeriodDays()` drives `Loan.dueOn`; demo section 2 |
| Custom exceptions and robust error handling | 15 | Two checked exceptions, validation everywhere, menu recovers from every error; demo section 4 |
| Collections and streams used appropriately | 15 | `Map` keyed by id; `listOverdue`, `searchByTitle` |
| File persistence works across runs | 15 | Section 5.2 (two runs) and demo section 8 |
| Code quality: naming, comments, no duplication | 10 | Single creation point (`LibraryItemFactory`), single borrow path (also used by the loader), comments on every non-obvious step |
| Report and class diagram | 10 | This document |

## 7. Limitations and possible extensions

* Fines are not calculated: overdue loans are only reported with the number of days late.
* Items cannot be removed or edited, and there is no member lookup or loan history after a return.
* Only the **current** date matters for overdue checks; the menu's option 8 lets you simulate time passing.
* Ideas: a `Strategy` for fine calculation (different rates per item type), an `Observer` that notifies members when an item
  becomes due, a unit-test suite, and a graphical or web front end.
