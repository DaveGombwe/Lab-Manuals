import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

// Requirement: a menu with add item, register member, borrow, return, list overdue, search by title.
// Run this one in a TERMINAL (it reads from the keyboard). LibraryDemo runs everything without typing.
public class LibraryApp {

    private static String ask(Scanner in, String prompt) {
        System.out.print(prompt);
        return in.nextLine().trim();
    }

    private static void printMenu(LocalDate today) {
        System.out.println();
        System.out.println("===== Library Management (today: " + today + ") =====");
        System.out.println(" 1  Add item");
        System.out.println(" 2  Register member");
        System.out.println(" 3  Borrow");
        System.out.println(" 4  Return");
        System.out.println(" 5  List overdue items");
        System.out.println(" 6  Search by title");
        System.out.println(" 7  List all items and members");
        System.out.println(" 8  Set today's date (to test overdue items)");
        System.out.println(" 0  Save and exit");
    }

    public static void run(Scanner in, LibraryStorage storage, LocalDate startDate) {
        Library library;
        try {
            library = storage.load();
            System.out.println("Loaded " + library.getItems().size() + " items, "
                    + library.getMembers().size() + " members, "
                    + library.getLoans().size() + " active loans from " + storage.getDir());
        } catch (IOException | RuntimeException e) {
            System.out.println("Could not load saved data (" + e.getMessage() + "). Starting empty.");
            library = new Library();
        }

        LocalDate today = startDate;
        boolean running = true;
        while (running) {
            printMenu(today);
            try {
                String choice = ask(in, "Choose an option: ");
                switch (choice) {
                    case "1" -> addItem(in, library);
                    case "2" -> registerMember(in, library);
                    case "3" -> borrow(in, library, today);
                    case "4" -> giveBack(in, library, today);
                    case "5" -> listOverdue(library, today);
                    case "6" -> search(in, library);
                    case "7" -> listAll(library);
                    case "8" -> today = LocalDate.parse(ask(in, "New date (yyyy-mm-dd): "));
                    case "0" -> running = false;
                    default  -> System.out.println("Unknown option: " + choice);
                }
            } catch (NoSuchElementException e) {                       // keyboard input ended (Ctrl+D / Ctrl+Z)
                System.out.println();
                System.out.println("Input ended.");
                running = false;
            } catch (ItemNotAvailableException | MemberLimitExceededException e) {
                System.out.println("Cannot borrow: " + e.getMessage());
            } catch (IllegalArgumentException | IllegalStateException | DateTimeParseException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        try {
            storage.save(library);
            System.out.println("Saved to " + storage.getDir() + ". Goodbye.");
        } catch (IOException e) {
            System.out.println("WARNING: could not save: " + e.getMessage());
        }
    }

    private static void addItem(Scanner in, Library library) {
        String kind = ask(in, "Type (B = book, D = DVD): ").toUpperCase();
        String type = switch (kind) {
            case "B" -> "BOOK";
            case "D" -> "DVD";
            default  -> throw new IllegalArgumentException("Type must be B or D");
        };
        String id = ask(in, "Item id: ");
        String title = ask(in, "Title: ");
        String extra = ask(in, type.equals("BOOK") ? "Author: " : "Running time (minutes): ");
        LibraryItem item = LibraryItemFactory.create(type, id, title, extra);
        library.addItem(item);
        System.out.println("Added: " + item);
    }

    private static void registerMember(Scanner in, Library library) {
        String id = ask(in, "Member id: ");
        String name = ask(in, "Name: ");
        Member member = new Member(id, name);
        library.registerMember(member);
        System.out.println("Registered: " + member);
    }

    private static void borrow(Scanner in, Library library, LocalDate today)
            throws ItemNotAvailableException, MemberLimitExceededException {
        String memberId = ask(in, "Member id: ");
        String itemId = ask(in, "Item id: ");
        Loan loan = library.borrow(memberId, itemId, today);
        System.out.println("Loan created: " + loan);
    }

    private static void giveBack(Scanner in, Library library, LocalDate today) {
        String itemId = ask(in, "Item id: ");
        Loan loan = library.giveBack(itemId, today);
        long late = loan.daysOverdue(today);
        System.out.println("Returned \"" + loan.getItem().getTitle() + "\""
                + (late > 0 ? " (" + late + " days overdue)" : " (on time)"));
    }

    private static void listOverdue(Library library, LocalDate today) {
        List<Loan> overdue = library.listOverdue(today);
        if (overdue.isEmpty()) {
            System.out.println("No overdue items as of " + today + ".");
            return;
        }
        System.out.println("Overdue as of " + today + ":");
        for (Loan l : overdue) {
            System.out.println("  " + l + "  -> " + l.daysOverdue(today) + " days overdue");
        }
    }

    private static void search(Scanner in, Library library) {
        String text = ask(in, "Search text: ");
        List<LibraryItem> found = library.searchByTitle(text);
        if (found.isEmpty()) {
            System.out.println("No titles contain \"" + text + "\".");
        } else {
            found.forEach(i -> System.out.println("  " + i));
        }
    }

    private static void listAll(Library library) {
        System.out.println("Items:");
        library.getItems().forEach(i -> System.out.println("  " + i));
        System.out.println("Members:");
        library.getMembers().forEach(m -> System.out.println("  " + m));
    }

    public static void main(String[] args) {
        String dir = args.length > 0 ? args[0] : "library-data";
        run(new Scanner(System.in), new LibraryStorage(Path.of(dir)), LocalDate.now());
    }
}
