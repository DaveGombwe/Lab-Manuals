import java.time.LocalDate;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

// The core service. Requirement: items and members stored in Map<String, ...> keyed by id.
public class Library {

    private final Map<String, LibraryItem> items = new LinkedHashMap<>();
    private final Map<String, Member> members = new LinkedHashMap<>();
    private final Map<String, Loan> loansByItemId = new LinkedHashMap<>();    // active loans only

    // ---------- registration ----------

    public void addItem(LibraryItem item) {
        if (items.containsKey(item.getId())) {
            throw new IllegalArgumentException("An item with id " + item.getId() + " already exists");
        }
        items.put(item.getId(), item);
    }

    public void registerMember(Member member) {
        if (members.containsKey(member.getId())) {
            throw new IllegalArgumentException("A member with id " + member.getId() + " already exists");
        }
        members.put(member.getId(), member);
    }

    // ---------- borrowing ----------

    public Loan borrow(String memberId, String itemId, LocalDate today)
            throws ItemNotAvailableException, MemberLimitExceededException {
        // 1. look up member and item (IllegalArgumentException if missing)
        Member member = requireMember(memberId);
        LibraryItem item = requireItem(itemId);

        // 2. check availability and the member's loan limit BEFORE changing anything
        if (!item.isAvailable()) {
            throw new ItemNotAvailableException(item.getId(), item.getTitle());
        }
        member.ensureCanBorrow();

        // 3. create the Loan, mark the item unavailable, record it on the member
        item.borrow(member);
        Loan loan = new Loan(item, member, today);
        member.addLoan(loan);
        loansByItemId.put(item.getId(), loan);
        return loan;
    }

    public Loan giveBack(String itemId, LocalDate today) {
        LibraryItem item = requireItem(itemId);
        Loan loan = loansByItemId.remove(item.getId());
        if (loan == null) {
            throw new IllegalStateException("Item " + itemId + " is not currently on loan");
        }
        loan.getMember().removeLoan(loan);
        item.giveBack();
        return loan;
    }

    // ---------- queries (streams) ----------

    public List<Loan> listOverdue(LocalDate asOf) {
        return loansByItemId.values().stream()
                .filter(loan -> loan.isOverdue(asOf))
                .sorted(Comparator.comparing(Loan::getDueOn))
                .toList();
    }

    public List<LibraryItem> searchByTitle(String text) {
        return items.values().stream()
                .filter(i -> i.getTitle().toLowerCase().contains(text.toLowerCase()))
                .sorted(Comparator.comparing(LibraryItem::getTitle))
                .toList();
    }

    public List<LibraryItem> getItems()  { return List.copyOf(items.values()); }
    public List<Member> getMembers()     { return List.copyOf(members.values()); }
    public List<Loan> getLoans()         { return List.copyOf(loansByItemId.values()); }

    // ---------- helpers ----------

    private Member requireMember(String id) {
        Member m = members.get(id == null ? null : id.trim());
        if (m == null) throw new IllegalArgumentException("No member with id " + id);
        return m;
    }

    private LibraryItem requireItem(String id) {
        LibraryItem item = items.get(id == null ? null : id.trim());
        if (item == null) throw new IllegalArgumentException("No item with id " + id);
        return item;
    }
}
