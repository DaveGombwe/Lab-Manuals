// Requirement: a Borrowable interface with borrow(Member) and giveBack()
public interface Borrowable {
    void borrow(Member member) throws ItemNotAvailableException;
    void giveBack();
}
