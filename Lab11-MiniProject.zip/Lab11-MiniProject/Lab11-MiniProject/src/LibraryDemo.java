import java.io.IOException;
import java.nio.file.Path;
import java.time.LocalDate;

// Runs EVERY feature of the mini-project with fixed dates, so the output is the same every time.
public class LibraryDemo {

    private static void heading(String text) {
        System.out.println();
        System.out.println("=== " + text + " ===");
    }

    public static void main(String[] args) throws IOException {
        Library lib = new Library();

        heading("1. Add items (Factory) and register members");
        lib.addItem(LibraryItemFactory.create("BOOK", "B1", "Effective Java", "Joshua Bloch"));
        lib.addItem(LibraryItemFactory.create("BOOK", "B2", "Clean Code, 2nd edition", "Robert Martin"));
        lib.addItem(LibraryItemFactory.create("BOOK", "B3", "Java: The Complete Reference", "Herbert Schildt"));
        lib.addItem(LibraryItemFactory.create("DVD", "D1", "The Matrix", "136"));
        lib.addItem(LibraryItemFactory.create("DVD", "D2", "Inception", "148"));
        lib.registerMember(new Member("M1", "Tariro"));
        lib.registerMember(new Member("M2", "Farai"));
        lib.getItems().forEach(i -> System.out.println("  " + i));
        lib.getMembers().forEach(m -> System.out.println("  " + m));

        heading("2. Polymorphism: same call, different loan period");
        for (LibraryItem item : lib.getItems()) {
            System.out.println("  " + item.typeName() + " " + item.getId() + " -> loanPeriodDays() = " + item.loanPeriodDays());
        }

        heading("3. Borrow (Tariro borrows 3 items on 2026-10-01)");
        LocalDate oct1 = LocalDate.of(2026, 10, 1);
        try {
            System.out.println("  " + lib.borrow("M1", "B1", oct1));
            System.out.println("  " + lib.borrow("M1", "D1", oct1));
            System.out.println("  " + lib.borrow("M1", "B2", oct1));
        } catch (ItemNotAvailableException | MemberLimitExceededException e) {
            System.out.println("  unexpected: " + e.getMessage());
        }

        heading("4. Custom exceptions");
        try {
            lib.borrow("M1", "B3", oct1);                       // Tariro already has 3 loans
        } catch (MemberLimitExceededException e) {
            System.out.println("  MemberLimitExceededException: " + e.getMessage());
        } catch (ItemNotAvailableException e) {
            System.out.println("  unexpected: " + e.getMessage());
        }
        try {
            lib.borrow("M2", "B1", oct1);                       // B1 is already on loan
        } catch (ItemNotAvailableException e) {
            System.out.println("  ItemNotAvailableException: " + e.getMessage());
        } catch (MemberLimitExceededException e) {
            System.out.println("  unexpected: " + e.getMessage());
        }
        try {
            lib.borrow("M9", "B1", oct1);                       // no such member
        } catch (IllegalArgumentException e) {
            System.out.println("  IllegalArgumentException: " + e.getMessage());
        } catch (ItemNotAvailableException | MemberLimitExceededException e) {
            System.out.println("  unexpected: " + e.getMessage());
        }

        try {
            System.out.println("  Farai borrows Inception on 2026-10-05: " + lib.borrow("M2", "D2", LocalDate.of(2026, 10, 5)));
        } catch (ItemNotAvailableException | MemberLimitExceededException e) {
            System.out.println("  unexpected: " + e.getMessage());
        }

        heading("5. Overdue items as of 2026-10-15 (stream: filter + sort by due date)");
        LocalDate oct15 = LocalDate.of(2026, 10, 15);
        for (Loan l : lib.listOverdue(oct15)) {
            System.out.println("  " + l + "  -> " + l.daysOverdue(oct15) + " days overdue");
        }

        heading("6. Search by title (stream: filter + sort), text = \"java\"");
        lib.searchByTitle("java").forEach(i -> System.out.println("  " + i));

        heading("7. Return The Matrix on 2026-10-15");
        Loan returned = lib.giveBack("D1", oct15);
        System.out.println("  Returned \"" + returned.getItem().getTitle() + "\", " + returned.daysOverdue(oct15) + " days overdue");
        System.out.println("  Overdue now:");
        lib.listOverdue(oct15).forEach(l -> System.out.println("    " + l));

        heading("8. Persistence: save to CSV, then reload into a brand-new Library");
        LibraryStorage storage = new LibraryStorage(Path.of("library-demo-data"));
        storage.save(lib);
        System.out.println("  Saved items.csv, members.csv and loans.csv to library-demo-data/");
        Library reloaded = storage.load();
        System.out.println("  Reloaded " + reloaded.getItems().size() + " items, "
                + reloaded.getMembers().size() + " members, " + reloaded.getLoans().size() + " active loans");
        reloaded.getItems().forEach(i -> System.out.println("    " + i));
        System.out.println("  Overdue after reload (as of 2026-10-15):");
        reloaded.listOverdue(oct15).forEach(l -> System.out.println("    " + l));
        System.out.println("  Title with a comma survived the CSV round trip: "
                + reloaded.searchByTitle("clean").get(0).getTitle());
    }
}
