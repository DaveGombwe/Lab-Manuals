import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

// Requirement: persist to CSV files on exit and reload on start.
//   items.csv    type,id,title,extra          (extra = author or minutes)
//   members.csv  id,name
//   loans.csv    itemId,memberId,borrowedOn   (only active loans)
public class LibraryStorage {

    private final Path dir;

    public LibraryStorage(Path dir) {
        this.dir = dir;
    }

    public Path getDir() { return dir; }

    public void save(Library library) throws IOException {
        Files.createDirectories(dir);

        List<String> itemLines = new ArrayList<>();
        for (LibraryItem i : library.getItems()) {
            itemLines.add(Csv.join(i.typeName(), i.getId(), i.getTitle(), i.extraInfo()));
        }
        Files.write(dir.resolve("items.csv"), itemLines);

        List<String> memberLines = new ArrayList<>();
        for (Member m : library.getMembers()) {
            memberLines.add(Csv.join(m.getId(), m.getName()));
        }
        Files.write(dir.resolve("members.csv"), memberLines);

        List<String> loanLines = new ArrayList<>();
        for (Loan l : library.getLoans()) {
            loanLines.add(Csv.join(l.getItem().getId(), l.getMember().getId(), l.getBorrowedOn().toString()));
        }
        Files.write(dir.resolve("loans.csv"), loanLines);
    }

    // Returns an empty library on the very first run (no files yet)
    public Library load() throws IOException {
        Library library = new Library();

        for (List<String> f : readRows("items.csv")) {
            library.addItem(LibraryItemFactory.create(f.get(0), f.get(1), f.get(2), f.get(3)));
        }
        for (List<String> f : readRows("members.csv")) {
            library.registerMember(new Member(f.get(0), f.get(1)));
        }
        // Replaying each saved loan through borrow() rebuilds every link and re-checks every rule
        for (List<String> f : readRows("loans.csv")) {
            try {
                library.borrow(f.get(1), f.get(0), LocalDate.parse(f.get(2)));
            } catch (ItemNotAvailableException | MemberLimitExceededException e) {
                throw new IOException("loans.csv is inconsistent: " + e.getMessage());
            }
        }
        return library;
    }

    private List<List<String>> readRows(String fileName) throws IOException {
        Path file = dir.resolve(fileName);
        List<List<String>> rows = new ArrayList<>();
        if (!Files.exists(file)) return rows;
        for (String line : Files.readAllLines(file)) {
            if (!line.isBlank()) rows.add(Csv.split(line));
        }
        return rows;
    }
}
