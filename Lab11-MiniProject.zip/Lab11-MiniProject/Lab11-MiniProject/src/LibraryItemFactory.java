// FACTORY pattern: callers ask for an item by TYPE NAME and never write 'new Book'/'new Dvd' themselves.
// Used both by the menu (add item) and by the CSV loader, so the creation logic exists exactly once.
public class LibraryItemFactory {

    public static LibraryItem create(String type, String id, String title, String extra) {
        return switch (type.trim().toUpperCase()) {
            case "BOOK" -> new Book(id, title, extra);
            case "DVD"  -> new Dvd(id, title, parseMinutes(extra));
            default     -> throw new IllegalArgumentException("Unknown item type: " + type);
        };
    }

    private static int parseMinutes(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Running time must be a whole number of minutes: " + text);
        }
    }
}
