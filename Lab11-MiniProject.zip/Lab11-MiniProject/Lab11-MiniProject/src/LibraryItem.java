// Requirement: abstract class LibraryItem (title, id) whose subclasses define loanPeriodDays()
public abstract class LibraryItem implements Borrowable {

    private final String id;
    private final String title;
    private boolean available = true;
    private Member borrower;                    // null while the item is on the shelf

    protected LibraryItem(String id, String title) {
        if (id == null || id.isBlank())       throw new IllegalArgumentException("Item id is required");
        if (title == null || title.isBlank()) throw new IllegalArgumentException("Title is required");
        this.id = id.trim();
        this.title = title.trim();
    }

    // What differs per kind of item (polymorphism): subclasses must supply these
    public abstract int loanPeriodDays();
    public abstract String typeName();          // "BOOK" or "DVD" (used in the CSV file)
    public abstract String extraInfo();         // author, or running time in minutes

    public String getId()        { return id; }
    public String getTitle()     { return title; }
    public boolean isAvailable() { return available; }

    @Override
    public void borrow(Member member) throws ItemNotAvailableException {
        if (!available) {
            throw new ItemNotAvailableException(id, title);
        }
        available = false;
        borrower = member;
    }

    @Override
    public void giveBack() {
        available = true;
        borrower = null;
    }

    @Override
    public String toString() {
        String status = available ? "available" : "on loan to " + borrower.getName();
        return String.format("[%s] %-4s \"%s\" (%s), %d-day loan, %s",
                id, typeName(), title, extraInfo(), loanPeriodDays(), status);
    }
}
