import java.util.ArrayList;
import java.util.List;

public class Member {

    public static final int MAX_LOANS = 3;

    private final String id;
    private final String name;
    private final List<Loan> loans = new ArrayList<>();

    public Member(String id, String name) {
        if (id == null || id.isBlank())     throw new IllegalArgumentException("Member id is required");
        if (name == null || name.isBlank()) throw new IllegalArgumentException("Member name is required");
        this.id = id.trim();
        this.name = name.trim();
    }

    public String getId()   { return id; }
    public String getName() { return name; }

    public List<Loan> getLoans() {
        return List.copyOf(loans);               // unmodifiable copy: callers cannot bypass the limit
    }

    public void ensureCanBorrow() throws MemberLimitExceededException {
        if (loans.size() >= MAX_LOANS) {
            throw new MemberLimitExceededException(id, MAX_LOANS);
        }
    }

    // package-private: only Library (same package) may change a member's loans
    void addLoan(Loan loan)    { loans.add(loan); }
    void removeLoan(Loan loan) { loans.remove(loan); }

    @Override
    public String toString() {
        return "[" + id + "] " + name + " (" + loans.size() + "/" + MAX_LOANS + " loans)";
    }
}
