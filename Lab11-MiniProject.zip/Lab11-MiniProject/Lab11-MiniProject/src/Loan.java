import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Loan {

    private final LibraryItem item;
    private final Member member;
    private final LocalDate borrowedOn;
    private final LocalDate dueOn;

    Loan(LibraryItem item, Member member, LocalDate borrowedOn) {
        this.item = item;
        this.member = member;
        this.borrowedOn = borrowedOn;
        this.dueOn = borrowedOn.plusDays(item.loanPeriodDays());     // polymorphic call
    }

    public LibraryItem getItem()    { return item; }
    public Member getMember()       { return member; }
    public LocalDate getBorrowedOn() { return borrowedOn; }
    public LocalDate getDueOn()     { return dueOn; }

    public boolean isOverdue(LocalDate asOf) {
        return asOf.isAfter(dueOn);
    }

    public long daysOverdue(LocalDate asOf) {
        return Math.max(0, ChronoUnit.DAYS.between(dueOn, asOf));
    }

    @Override
    public String toString() {
        return "\"" + item.getTitle() + "\" borrowed by " + member.getName()
                + " on " + borrowedOn + ", due " + dueOn;
    }
}
