// Requirement: custom CHECKED exception, thrown when a member already has the maximum number of loans
public class MemberLimitExceededException extends Exception {
    public MemberLimitExceededException(String memberId, int limit) {
        super("Member " + memberId + " already has the maximum of " + limit + " loans");
    }
}
