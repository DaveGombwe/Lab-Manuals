# Lab 11: Design Patterns and the Mini-Project (Library Management System)

Complete solution to the Lab 11 mini-project of the *Object-Oriented Programming in Java* lab manual,
plus the two pattern programs from the lab (Programs 11.1 and 11.2).
Requires **JDK 17 or later**. Every file is in the default package, in `src/`.

**`REPORT.md` is the project report: design, class diagram, requirement-by-requirement mapping, marking-guide checklist and test evidence.**

## Run it

| What | Run | Notes |
| --- | --- | --- |
| Full automatic demonstration of every feature | `LibraryDemo` | No typing needed; fixed dates, so output is always the same |
| The interactive menu application | `LibraryApp` | Needs a **terminal**: use the Java extension's Run button, or `cd src`, `javac *.java`, `java LibraryApp` |
| Program 11.1 Singleton and Factory | `SingletonFactoryDemo` | From the manual, unchanged |
| Program 11.2 Strategy and Observer | `StrategyObserverDemo` | From the manual, unchanged |

`LibraryApp` saves to a `library-data/` folder (next to where you run it) when you choose **0 Save and exit** and reloads it next time.
Use menu option **8** to move "today" forward and make loans overdue. Pass a different folder as an argument to keep separate libraries.

## Open in VS Code

1. Install the **Extension Pack for Java** if VS Code offers it.
2. **File > Open Folder...** and choose the folder that directly contains `src` and `.vscode`
   (if unzipping created a folder inside a folder, open the inner one).
3. Open `LibraryDemo.java` and click **Run** above `main`.

## Source files

| File | Role |
| --- | --- |
| `Borrowable.java` | Interface: `borrow(Member)`, `giveBack()` |
| `LibraryItem.java` | Abstract class (id, title, availability); implements `Borrowable` |
| `Book.java`, `Dvd.java` | Subclasses with their own `loanPeriodDays()` (21 and 7) |
| `Member.java`, `Loan.java` | Members (max 3 loans) and loans (borrow date, due date, overdue test) |
| `ItemNotAvailableException.java`, `MemberLimitExceededException.java` | Custom checked exceptions |
| `Library.java` | Core service: `Map`s keyed by id, borrow/return, overdue and search (streams) |
| `LibraryItemFactory.java` | Factory pattern: creates a `Book` or `Dvd` from a type name |
| `Csv.java`, `LibraryStorage.java` | CSV persistence (save on exit, reload on start) |
| `LibraryApp.java` | Menu application |
| `LibraryDemo.java` | Scripted demonstration of everything |
| `SingletonFactoryDemo.java`, `StrategyObserverDemo.java` | Programs 11.1 and 11.2 from the manual |
