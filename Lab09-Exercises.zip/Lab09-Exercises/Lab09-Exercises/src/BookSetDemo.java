import java.util.HashSet;
import java.util.Set;

// Exercise 9.3: prove that a HashSet<Book> rejects duplicates
public class BookSetDemo {
    public static void main(String[] args) {
        Book a = new Book("978-0134685991", "Effective Java");
        Book b = new Book("978-0132350884", "Clean Code");
        Book dup = new Book("978-0134685991", "Effective Java (2nd copy)");   // same ISBN as a

        Set<Book> library = new HashSet<>();
        System.out.println("add a   -> " + library.add(a));      // true: new
        System.out.println("add b   -> " + library.add(b));      // true: new
        System.out.println("add dup -> " + library.add(dup));    // false: equal to a, rejected
        System.out.println("size = " + library.size());          // 2
        System.out.println("contents: " + library);
        System.out.println("a.equals(dup) = " + a.equals(dup) + ", same hashCode = "
                + (a.hashCode() == dup.hashCode()));

        // Without equals()/hashCode() the set cannot tell the duplicate apart
        Set<BrokenBook> broken = new HashSet<>();
        broken.add(new BrokenBook("978-0134685991", "Effective Java"));
        broken.add(new BrokenBook("978-0134685991", "Effective Java"));
        System.out.println("BrokenBook set size = " + broken.size() + "   <- duplicate NOT rejected");
    }
}
