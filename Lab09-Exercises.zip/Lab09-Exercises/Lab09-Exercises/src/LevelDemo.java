// Exercise 9.1: a switch over the enum that prints advice for each constant
public class LevelDemo {

    // EXPLAIN: a switch EXPRESSION over an enum must cover every constant, so if someone adds
    // a new Level, the compiler flags this method instead of silently ignoring the new value.
    static String advice(Level level) {
        return switch (level) {
            case LOW    -> "Low risk: carry on as normal.";
            case MEDIUM -> "Medium risk: double-check your work.";
            case HIGH   -> "High risk: stop and ask for help!";
        };
    }

    public static void main(String[] args) {
        for (Level level : Level.values()) {                 // values() lists constants in declared order
            System.out.println(level + " (ordinal " + level.ordinal() + "): " + advice(level));
        }

        Level chosen = Level.valueOf("HIGH");                // text -> constant
        System.out.println("valueOf(\"HIGH\") == Level.HIGH ? " + (chosen == Level.HIGH));
        System.out.println("MEDIUM comes after LOW? " + (Level.MEDIUM.compareTo(Level.LOW) > 0));

        try {
            Level.valueOf("EXTREME");
        } catch (IllegalArgumentException e) {
            System.out.println("valueOf(\"EXTREME\") failed: " + e.getMessage());
        }
    }
}
