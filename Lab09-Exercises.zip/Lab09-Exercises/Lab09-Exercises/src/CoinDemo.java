import java.util.Map;

public class CoinDemo {
    public static void main(String[] args) {
        int[] amounts = {91, 41, 30, 5, 99, 0};
        for (int amount : amounts) {
            Map<Coin, Integer> change = Coin.fewestCoins(amount);
            int total = Coin.totalCoins(change);
            System.out.println(amount + " cents -> " + (change.isEmpty() ? "no coins" : change)
                    + "  (" + total + (total == 1 ? " coin)" : " coins)"));
        }
        try {
            Coin.fewestCoins(-5);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
    }
}
