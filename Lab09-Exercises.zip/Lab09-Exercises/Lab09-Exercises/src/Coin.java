import java.util.LinkedHashMap;
import java.util.Map;

// Exercise 9.5 (Challenge): an enum with a field, a constructor and methods
public enum Coin {
    PENNY(1), NICKEL(5), DIME(10), QUARTER(25);

    private final int cents;

    Coin(int cents) {                      // enum constructors are implicitly private
        this.cents = cents;
    }

    public int getCents() { return cents; }

    // Fewest coins for an amount in cents. GREEDY: always take as many of the largest coin as fit.
    // This is optimal for these four denominations (but NOT for every coin system).
    public static Map<Coin, Integer> fewestCoins(int amount) {
        if (amount < 0) {
            throw new IllegalArgumentException("Amount cannot be negative: " + amount);
        }
        Map<Coin, Integer> result = new LinkedHashMap<>();    // keeps largest-first order
        Coin[] all = values();
        int remaining = amount;
        for (int i = all.length - 1; i >= 0; i--) {           // QUARTER first, PENNY last
            int count = remaining / all[i].cents;
            if (count > 0) {
                result.put(all[i], count);
                remaining -= count * all[i].cents;
            }
        }
        return result;
    }

    public static int totalCoins(Map<Coin, Integer> change) {
        int total = 0;
        for (int n : change.values()) total += n;
        return total;
    }
}
