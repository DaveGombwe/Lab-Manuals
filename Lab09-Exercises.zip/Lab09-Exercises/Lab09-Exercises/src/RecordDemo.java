public class RecordDemo {
    public static void main(String[] args) {
        Student s1 = new Student("Tariro", 19);
        Student s2 = new Student("Tariro", 19);
        Student s3 = new Student("Farai", 21);

        // 1. Print: toString() is generated
        System.out.println(s1);

        // 2. Compare: equals() compares the COMPONENTS, not the addresses
        System.out.println("s1.equals(s2) = " + s1.equals(s2));      // true: same values
        System.out.println("s1 == s2      = " + (s1 == s2));         // false: two objects
        System.out.println("s1.equals(s3) = " + s1.equals(s3));      // false: different values
        System.out.println("same hashCode = " + (s1.hashCode() == s2.hashCode()));

        // 3. Read a component: accessor methods are named after the components
        System.out.println("name  = " + s1.name());
        System.out.println("age   = " + s1.age());

        // s1.age = 20;       // COMPILE ERROR: record fields are final, so records are immutable
    }
}
