import java.util.Iterator;
import java.util.NoSuchElementException;

// Exercise 9.4 (Intermediate): a singly linked list. Implementing Iterable<T> is what makes
//     for (String s : list) { ... }
// legal. (Named MyLinkedList so it is never confused with java.util.LinkedList.)
public class MyLinkedList<T> implements Iterable<T> {

    // STATIC nested class: a Node does not need a reference to any particular list,
    // so it is static and private (an implementation detail nobody else should see).
    private static class Node<E> {
        final E value;
        Node<E> next;

        Node(E value) {
            this.value = value;
        }
    }

    private Node<T> head;
    private Node<T> tail;
    private int size;

    public void add(T value) {                 // append at the end
        Node<T> node = new Node<>(value);
        if (head == null) {
            head = node;
        } else {
            tail.next = node;
        }
        tail = node;
        size++;
    }

    public void addFirst(T value) {            // insert at the front
        Node<T> node = new Node<>(value);
        node.next = head;
        head = node;
        if (tail == null) tail = node;
        size++;
    }

    public int size() { return size; }

    @Override
    public Iterator<T> iterator() {
        return new ListIterator();
    }

    // INNER (non-static) class: every ListIterator belongs to ONE list and can read that
    // list's private field 'head' directly. That is exactly what an iterator needs.
    private class ListIterator implements Iterator<T> {
        private Node<T> current = head;        // starts at the outer list's head

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public T next() {
            if (current == null) {
                throw new NoSuchElementException();
            }
            T value = current.value;
            current = current.next;
            return value;
        }
    }
}
