// Exercise 9.2 (Basic): one line gives private final fields, a constructor, accessors,
// equals(), hashCode() and toString()
public record Student(String name, int age) {
}
