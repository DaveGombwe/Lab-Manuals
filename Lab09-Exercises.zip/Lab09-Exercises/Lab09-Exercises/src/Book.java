import java.util.Objects;

// Exercise 9.3 (Intermediate): two Books are "the same book" when their ISBN is the same
public class Book {
    private final String isbn;
    private final String title;

    public Book(String isbn, String title) {
        this.isbn = isbn;
        this.title = title;
    }

    public String getIsbn()  { return isbn; }
    public String getTitle() { return title; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;                       // same object: trivially equal
        if (!(o instanceof Book other)) return false;     // null or a different type
        return isbn.equals(other.isbn);                    // identity of a Book = its ISBN
    }

    // CONTRACT: equal objects MUST have equal hash codes, so hash the SAME field(s) as equals()
    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }

    @Override
    public String toString() {
        return title + " [" + isbn + "]";
    }
}
