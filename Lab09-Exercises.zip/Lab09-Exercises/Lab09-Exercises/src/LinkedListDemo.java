public class LinkedListDemo {
    public static void main(String[] args) {
        MyLinkedList<String> names = new MyLinkedList<>();
        names.add("Tariro");
        names.add("Farai");
        names.add("Rudo");
        names.addFirst("Anesu");

        System.out.println("size = " + names.size());
        for (String n : names) {                 // the for-each loop calls iterator() for us
            System.out.println("  " + n);
        }

        MyLinkedList<Integer> numbers = new MyLinkedList<>();
        for (int i = 1; i <= 5; i++) numbers.add(i * i);
        int sum = 0;
        for (int n : numbers) sum += n;
        System.out.println("sum of squares 1..5 = " + sum);

        // Two iterators over the same list are independent
        var it1 = numbers.iterator();
        var it2 = numbers.iterator();
        it1.next();
        it1.next();
        System.out.println("it1 is at the 3rd item: " + it1.next() + ", it2 is still at the 1st: " + it2.next());
    }
}
