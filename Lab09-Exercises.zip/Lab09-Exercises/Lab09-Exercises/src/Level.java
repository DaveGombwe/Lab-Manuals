// Exercise 9.1 (Basic): an enum is a fixed set of named constants (each is a singleton object)
public enum Level {
    LOW, MEDIUM, HIGH
}
