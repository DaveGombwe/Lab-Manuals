// For contrast: the same class WITHOUT equals()/hashCode(), so it inherits Object's versions,
// which compare addresses (identity), not content.
public class BrokenBook {
    private final String isbn;
    private final String title;

    public BrokenBook(String isbn, String title) {
        this.isbn = isbn;
        this.title = title;
    }

    @Override
    public String toString() {
        return title + " [" + isbn + "]";
    }
}
