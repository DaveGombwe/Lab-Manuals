import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

// Exercise 10.5 (Challenge): load learners.csv, group by grade band, write ONE report file per band
public class LearnerReports {

    static void createSampleIfMissing(Path csv) throws IOException {
        if (Files.exists(csv)) return;
        Files.write(csv, List.of(
            "Ada,1,3.9", "Kuda,2,3.2", "Tariro,3,3.6", "Farai,4,2.8", "Rudo,5,3.0",
            "Chipo,6,2.4", "Tendai,7,3.5", "Nyasha,8,2.9", "Gift,9,3.8", "Anesu,10,3.1"));
        System.out.println("(created sample " + csv + "; edit it and run again to use your own data)");
    }

    static List<Learner> load(Path csv) throws IOException {
        List<Learner> result = new ArrayList<>();
        for (String line : Files.readAllLines(csv)) {
            if (!line.isBlank()) result.add(Learner.fromCsv(line));
        }
        return result;
    }

    static void writeReport(String band, List<Learner> members) throws IOException {
        double avg = members.stream().mapToDouble(Learner::gpa).average().orElse(0);
        List<String> lines = new ArrayList<>();
        lines.add("Grade band " + band + " report");
        lines.add("Learners: " + members.size());
        lines.add(String.format("Average GPA: %.2f", avg));
        lines.add("--------------------");
        for (Learner l : members) {
            lines.add(String.format("%-8s roll %-3d GPA %.1f", l.name(), l.roll(), l.gpa()));
        }
        Files.write(Path.of("report-" + band + ".txt"), lines);
    }

    public static void main(String[] args) {
        Path csv = Path.of("learners.csv");
        try {
            createSampleIfMissing(csv);
            List<Learner> learners = load(csv);
            System.out.println("Loaded " + learners.size() + " learners");

            // groupingBy: classify each learner by band(); TreeMap keeps the keys in order A, B, C
            Map<String, List<Learner>> byBand = learners.stream()
                    .collect(Collectors.groupingBy(Learner::band, TreeMap::new, Collectors.toList()));

            for (Map.Entry<String, List<Learner>> e : byBand.entrySet()) {
                writeReport(e.getKey(), e.getValue());
                System.out.println("Wrote report-" + e.getKey() + ".txt (" + e.getValue().size() + " learners)");
            }

            for (String band : byBand.keySet()) {
                System.out.println();
                System.out.println("== report-" + band + ".txt ==");
                Files.readAllLines(Path.of("report-" + band + ".txt")).forEach(System.out::println);
            }
        } catch (IOException e) {
            System.out.println("File problem: " + e.getMessage());
        }
    }
}
