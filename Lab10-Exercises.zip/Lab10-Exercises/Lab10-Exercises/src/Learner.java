// Exercise 10.5: the Learner record from Program 10.2, plus the grade band
public record Learner(String name, int roll, double gpa) {

    public String toCsv() {
        return name + "," + roll + "," + gpa;
    }

    // Parses one CSV line "name,roll,gpa"
    public static Learner fromCsv(String line) {
        String[] p = line.split(",");
        return new Learner(p[0].trim(), Integer.parseInt(p[1].trim()), Double.parseDouble(p[2].trim()));
    }

    // Grade band: A = GPA 3.5 or higher, B = 3.0 up to 3.5, C = below 3.0
    public String band() {
        if (gpa >= 3.5) return "A";
        if (gpa >= 3.0) return "B";
        return "C";
    }
}
