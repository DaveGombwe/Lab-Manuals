import java.util.List;

// Exercise 10.4 (Intermediate): names of students ABOVE the class average, sorted alphabetically
public class AboveAverage {
    public static void main(String[] args) {
        List<Student> students = List.of(
            new Student("Tariro", 78),
            new Student("Farai", 65),
            new Student("Rudo", 91),
            new Student("Chipo", 55),
            new Student("Tendai", 82),
            new Student("Nyasha", 70)
        );

        // Terminal operation 1: average() on a stream of doubles
        double average = students.stream()
                .mapToDouble(Student::score)           // method reference
                .average()
                .orElse(0.0);                          // average() returns an OptionalDouble
        System.out.printf("Class average: %.2f%n", average);

        // Pipeline: source -> filter -> map -> sorted -> terminal
        List<String> above = students.stream()
                .filter(s -> s.score() > average)      // keep only above-average students
                .map(Student::name)                    // Student -> String
                .sorted()                              // alphabetical (natural String order)
                .toList();                             // terminal operation: runs the pipeline

        System.out.println("Above average (A-Z): " + above);
        // The original list is untouched: streams never modify their source
        System.out.println("Original list size still " + students.size());
    }
}
