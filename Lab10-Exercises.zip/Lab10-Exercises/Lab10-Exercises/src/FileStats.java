import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

// Exercise 10.3 (Intermediate): count the lines, words and characters of a text file
public class FileStats {

    public record Stats(long lines, long words, long characters) { }

    public static Stats count(Path file) throws IOException {
        String text = Files.readString(file);                       // whole file as one String
        long lines = text.lines().count();
        long words = text.isBlank() ? 0
                : Arrays.stream(text.trim().split("\\s+")).count();  // runs of whitespace separate words
        long characters = text.length();                             // includes line-break characters
        return new Stats(lines, words, characters);
    }

    // Writes a small sample file so the program can be run without preparing anything
    static void createSample(Path file) throws IOException {
        Files.writeString(file,
              "Object-oriented programming models real things.\n"
            + "Classes describe them.\n"
            + "Objects are the actual instances.\n");
    }

    // Usage: java FileStats [path-to-file]     (with no argument a sample file is created)
    public static void main(String[] args) {
        try {
            Path file;
            if (args.length > 0) {
                file = Path.of(args[0]);
            } else {
                file = Path.of("sample.txt");
                createSample(file);
                System.out.println("(no file given: created " + file + ")");
            }
            Stats s = count(file);
            System.out.println("File       : " + file);
            System.out.println("Lines      : " + s.lines());
            System.out.println("Words      : " + s.words());
            System.out.println("Characters : " + s.characters() + " (line breaks included)");
        } catch (IOException e) {
            System.out.println("Could not read the file: " + e);
        }
    }
}
