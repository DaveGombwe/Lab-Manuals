import java.io.IOException;
import java.nio.file.Path;
import java.util.Scanner;

// Exercise 10.1 with SCRIPTED input (no typing needed)
public class SaveLinesDemo {
    public static void main(String[] args) {
        Path file = Path.of("typed-lines.txt");
        String script = "Java files are easy\nWe write with Files.write\nAnd read with Files.readAllLines\n"
                      + "IOException is checked\nSo we must handle it\n";
        try {
            SaveLines.saveLines(new Scanner(script), file, 5, true);
            System.out.println("--- reading back ---");
            for (String line : SaveLines.readBack(file)) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("File problem: " + e.getMessage());
        }
    }
}
