import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

// Exercise 10.2 (Basic): a Predicate plus removeIf deletes every even number
public class RemoveEvens {
    public static void main(String[] args) {
        // new ArrayList<>(...) is needed: List.of(...) is immutable and removeIf would throw
        List<Integer> numbers = new ArrayList<>(List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12));
        System.out.println("before: " + numbers);

        // EXPLAIN: Predicate<Integer> is a functional interface: one method, boolean test(Integer)
        Predicate<Integer> isEven = n -> n % 2 == 0;

        numbers.removeIf(isEven);               // removes every element for which the predicate is true
        System.out.println("after : " + numbers);

        // The predicate is reusable and can be combined
        Predicate<Integer> bigger5 = n -> n > 5;
        numbers.removeIf(bigger5.negate());     // also remove everything that is NOT bigger than 5
        System.out.println("then removing everything <= 5: " + numbers);
    }
}
