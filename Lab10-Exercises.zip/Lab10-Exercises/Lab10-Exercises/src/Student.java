// Exercise 10.4: a record with the data we need
public record Student(String name, double score) {
}
