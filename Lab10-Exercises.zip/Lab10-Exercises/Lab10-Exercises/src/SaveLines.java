import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Exercise 10.1 (Basic): save five lines typed by the user to a file, then read them back
public class SaveLines {

    // Reads up to 'count' lines from 'in' (echoing them when echo is true) and writes them to 'file'
    public static void saveLines(Scanner in, Path file, int count, boolean echo) throws IOException {
        List<String> lines = new ArrayList<>();
        for (int i = 1; i <= count; i++) {
            System.out.print("Line " + i + ": ");
            if (!in.hasNextLine()) {
                System.out.println("(no more input)");
                break;
            }
            String line = in.nextLine();
            if (echo) System.out.println(line);
            lines.add(line);
        }
        Files.write(file, lines);                     // creates or overwrites; UTF-8
        System.out.println("Saved " + lines.size() + " lines to " + file);
    }

    public static List<String> readBack(Path file) throws IOException {
        return Files.readAllLines(file);
    }

    public static void main(String[] args) {
        Path file = Path.of("typed-lines.txt");
        try {
            saveLines(new Scanner(System.in), file, 5, false);
            System.out.println("--- reading back ---");
            for (String line : readBack(file)) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("File problem: " + e.getMessage());
        }
    }
}
