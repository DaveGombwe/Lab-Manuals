// Exercise 8.4 with a built-in paragraph (no typing needed)
public class WordFrequencyDemo {
    public static void main(String[] args) {
        String paragraph = "The cat sat on the mat. The dog sat on the log, and the cat watched the dog. "
                         + "A cat is not a dog.";
        System.out.println(paragraph);
        System.out.println();
        WordFrequency.printReport(paragraph);
    }
}
