import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

// Exercise 8.4 (Intermediate): word frequencies with a Map, printed from most to least frequent
public class WordFrequency {

    // Counts words, ignoring case and punctuation
    public static Map<String, Integer> count(String text) {
        Map<String, Integer> freq = new HashMap<>();
        for (String word : text.toLowerCase().split("[^\\p{L}']+")) {
            if (!word.isEmpty()) {
                freq.merge(word, 1, Integer::sum);       // new word -> 1, existing -> old + 1
            }
        }
        return freq;
    }

    // A HashMap has no order, so copy the entries to a list and sort THAT:
    // highest count first, and alphabetical when counts are equal.
    public static List<Map.Entry<String, Integer>> sortedByFrequency(Map<String, Integer> freq) {
        List<Map.Entry<String, Integer>> entries = new ArrayList<>(freq.entrySet());
        entries.sort((a, b) -> {
            int byCount = Integer.compare(b.getValue(), a.getValue());
            return byCount != 0 ? byCount : a.getKey().compareTo(b.getKey());
        });
        return entries;
    }

    public static void printReport(String text) {
        for (Map.Entry<String, Integer> e : sortedByFrequency(count(text))) {
            System.out.printf("%-10s %d%n", e.getKey(), e.getValue());
        }
    }

    // Interactive version: type a paragraph, finish with an empty line
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Type a paragraph, then press Enter on an empty line:");
        StringBuilder sb = new StringBuilder();
        while (in.hasNextLine()) {
            String line = in.nextLine();
            if (line.isBlank()) break;
            sb.append(line).append(' ');
        }
        printReport(sb.toString());
    }
}
