public class StackDemo {
    public static void main(String[] args) {
        Stack<Integer> numbers = new Stack<>();
        numbers.push(10);
        numbers.push(20);
        numbers.push(30);
        System.out.println("peek: " + numbers.peek() + ", size: " + numbers.size());

        int top = numbers.pop();              // no cast needed: pop() returns Integer
        System.out.println("popped: " + top + ", then " + numbers.pop());
        System.out.println("isEmpty? " + numbers.isEmpty());

        // The same class works for any type
        Stack<String> words = new Stack<>();
        words.push("one");
        words.push("two");
        System.out.println("popped: " + words.pop());

        // words.push(5);                     // COMPILE ERROR: Stack<String> only accepts String

        numbers.pop();
        try {
            numbers.pop();
        } catch (IllegalStateException e) {
            System.out.println("pop on empty stack: " + e.getMessage());
        }
    }
}
