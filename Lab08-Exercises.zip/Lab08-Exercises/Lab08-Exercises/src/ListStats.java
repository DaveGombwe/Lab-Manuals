import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

// Exercise 8.1 (Basic): 10 integers in an ArrayList; sum, maximum, and the list in reverse
public class ListStats {
    public static void main(String[] args) {
        // EXPLAIN: ArrayList<Integer> - generics force the elements to be Integer (int is boxed automatically)
        List<Integer> nums = new ArrayList<>(List.of(14, 7, 29, 3, 18, 25, 9, 31, 12, 20));
        System.out.println("List    : " + nums);

        int sum = 0;
        for (int n : nums) {                 // unboxing: Integer -> int
            sum += n;
        }
        System.out.println("Sum     : " + sum);

        int max = nums.get(0);
        for (int n : nums) {
            if (n > max) max = n;
        }
        System.out.println("Maximum : " + max);

        // Reverse by hand: walk from the last index to the first
        List<Integer> reversed = new ArrayList<>();
        for (int i = nums.size() - 1; i >= 0; i--) {
            reversed.add(nums.get(i));
        }
        System.out.println("Reversed: " + reversed);

        // The library way (on a copy, so the original order is kept)
        List<Integer> copy = new ArrayList<>(nums);
        Collections.reverse(copy);
        System.out.println("Library : " + copy + "  (max via Collections.max = " + Collections.max(nums) + ")");
    }
}
