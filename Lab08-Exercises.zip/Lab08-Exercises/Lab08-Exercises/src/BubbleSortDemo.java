import java.util.Arrays;

public class BubbleSortDemo {
    public static void main(String[] args) {
        Integer[] numbers = {5, 2, 9, 1, 7, 3};
        String[] words = {"pear", "apple", "fig", "banana", "cherry"};
        Double[] decimals = {2.5, -1.0, 9.75, 0.0};

        BubbleSort.bubbleSort(numbers);        // T is inferred as Integer
        BubbleSort.bubbleSort(words);          // T is inferred as String
        BubbleSort.bubbleSort(decimals);       // T is inferred as Double

        System.out.println("Integer[]: " + Arrays.toString(numbers));
        System.out.println("String[] : " + Arrays.toString(words));
        System.out.println("Double[] : " + Arrays.toString(decimals));

        // A primitive int[] CANNOT be passed directly (see does-not-compile/).
        // Workaround: box it into an Integer[] first.
        int[] primitive = {8, 3, 6, 1};
        Integer[] boxed = Arrays.stream(primitive).boxed().toArray(Integer[]::new);
        BubbleSort.bubbleSort(boxed);
        System.out.println("boxed int[]: " + Arrays.toString(boxed));
    }
}
