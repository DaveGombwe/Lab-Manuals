import java.util.ArrayList;

// Exercise 8.3 (Intermediate): a GENERIC stack. T is a placeholder for any reference type.
public class Stack<T> {

    private final ArrayList<T> items = new ArrayList<>();      // backing store: top = LAST element

    public void push(T item) {
        items.add(item);
    }

    public T pop() {
        if (items.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return items.remove(items.size() - 1);
    }

    public T peek() {
        if (items.isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return items.get(items.size() - 1);
    }

    public boolean isEmpty() { return items.isEmpty(); }
    public int size()        { return items.size(); }
}
