import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

// Exercise 8.2 (Basic): remove duplicates from a list of names using a Set
public class DedupeNames {
    public static void main(String[] args) {
        List<String> names = List.of("Tariro", "Farai", "Tariro", "Rudo", "Farai", "Chipo", "Tariro", "Anesu");
        System.out.println("With duplicates : " + names);

        // A Set never holds duplicates. The three common sets differ only in ORDER:
        Set<String> hash = new HashSet<>(names);              // no promised order
        Set<String> linked = new LinkedHashSet<>(names);      // keeps first-seen order
        Set<String> sorted = new TreeSet<>(names);            // alphabetical

        System.out.println("LinkedHashSet   : " + linked + "   <- usual choice for 'remove duplicates'");
        System.out.println("TreeSet (sorted): " + sorted);
        System.out.println("HashSet         : " + hash.size() + " names, order not guaranteed");

        // add() reports whether the element was new
        Set<String> seen = new LinkedHashSet<>();
        for (String n : names) {
            if (!seen.add(n)) {
                System.out.println("  duplicate skipped: " + n);
            }
        }
    }
}
