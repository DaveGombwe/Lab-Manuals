// Exercise 8.5 (Challenge): a generic bubble sort
public class BubbleSort {

    // EXPLAIN: T extends Comparable<T> promises that any two T's can be compared with compareTo
    public static <T extends Comparable<T>> void bubbleSort(T[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < arr.length - 1 - i; j++) {
                if (arr[j].compareTo(arr[j + 1]) > 0) {
                    T tmp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = tmp;
                    swapped = true;
                }
            }
            if (!swapped) break;          // already sorted: stop early
        }
    }
}
