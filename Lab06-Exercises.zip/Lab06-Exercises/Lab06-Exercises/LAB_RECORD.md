# Lab 6: Abstraction, Abstract Classes and Interfaces: Exercises

## Lab record

Solutions to the five exercises at the end of Lab 6. All output below was produced by actually running the programs (JDK 21).

| # | Level | Files | Run |
| --- | --- | --- | --- |
| 6.1 | Basic | Shape.java, Circle.java, Rectangle.java, Square.java, ShapeDemo.java | `java ShapeDemo` |
| 6.2 | Basic | Flyable.java, Bird.java, Aeroplane.java, FlyableDemo.java | `java FlyableDemo` |
| 6.3 | Intermediate | Account.java, SavingsAccount.java, CurrentAccount.java, AccountDemo.java | `java AccountDemo` |
| 6.4 | Intermediate | Student.java, MarksComparator.java, StudentSortDemo.java | `java StudentSortDemo` |
| 6.5 | Challenge | Greeter.java, Welcomer.java, Receptionist.java, DefaultConflictDemo.java, ClassWinsDemo.java, does-not-compile/Receptionist_FAILS.java.txt | `java DefaultConflictDemo` |

## Exercise 6.1 (Basic)

**Task:** Create an abstract Shape with abstract area() and perimeter(), and implement Circle, Rectangle and Square.

**Files:** Shape.java, Circle.java, Rectangle.java, Square.java, ShapeDemo.java

**Run:** `java ShapeDemo`

**Output**

```
Circle    area=   78.54 perimeter=   31.42
Rectangle area=   24.00 perimeter=   20.00
Square    area=    9.00 perimeter=   12.00
Total area: 111.54
```

`Shape` declares *what* every shape can do and cannot be instantiated (`new Shape()` is a compile error). Each concrete subclass must implement both abstract methods. `Square` extends `Rectangle` and passes the same value for width and height, reusing all of Rectangle's code. `describe()` is a concrete method in `Shape` that calls the abstract ones.

## Exercise 6.2 (Basic)

**Task:** Define an interface Flyable with fly() and implement it for Bird and Aeroplane, which share no superclass.

**Files:** Flyable.java, Bird.java, Aeroplane.java, FlyableDemo.java

**Run:** `java FlyableDemo`

**Output**

```
The eagle flaps its wings and flies
The Boeing 737 accelerates down the runway and takes off
The swallow flaps its wings and flies
Bird's superclass:      Object
Aeroplane's superclass: Object
```

`Bird` and `Aeroplane` are unrelated (the demo shows that both extend only `Object`), yet both can be stored in a `Flyable[]` because each promises the `fly()` capability. An interface describes a **capability**, not a family tree, which is why it fits unrelated classes where inheritance would not.

## Exercise 6.3 (Intermediate)

**Task:** Build an abstract class Account with a concrete deposit() and an abstract monthlyFee(). Implement SavingsAccount and CurrentAccount.

**Files:** Account.java, SavingsAccount.java, CurrentAccount.java, AccountDemo.java

**Run:** `java AccountDemo`

**Output**

```
--- before ---
SavingsAccount SAV-001 [Tariro] balance:   1500.00  monthly fee:   0.00
SavingsAccount SAV-002 [Farai] balance:    400.00  monthly fee:   5.00
CurrentAccount CUR-001 [Rudo] balance:    800.00  monthly fee:  15.00

--- after Farai deposits 700 ---
SavingsAccount SAV-001 [Tariro] balance:   1500.00  monthly fee:   0.00
SavingsAccount SAV-002 [Farai] balance:   1100.00  monthly fee:   0.00
CurrentAccount CUR-001 [Rudo] balance:    800.00  monthly fee:  15.00

--- after the monthly fee ---
SavingsAccount SAV-001 [Tariro] balance:   1500.00  monthly fee:   0.00
SavingsAccount SAV-002 [Farai] balance:   1100.00  monthly fee:   0.00
CurrentAccount CUR-001 [Rudo] balance:    785.00  monthly fee:  15.00
```

`deposit()` is identical for all accounts, so it is written once in `Account`. The fee differs, so `monthlyFee()` is abstract: savings is free at 1000 or more (else 5.00), current is a flat 15.00. `applyMonthlyFee()` is a concrete method that calls the abstract one (the *template method* idea). The demo shows Farai's savings fee drop to 0.00 after a deposit lifts the balance to 1100. **Why an abstract class and not an interface?** The accounts share *state* (number, owner, balance) and concrete code; an interface cannot hold instance fields.

## Exercise 6.4 (Intermediate)

**Task:** Make Student implements Comparable<Student> sorted by name, then add a Comparator sorted by marks.

**Files:** Student.java, MarksComparator.java, StudentSortDemo.java

**Run:** `java StudentSortDemo`

**Output**

```
original      : [Tariro(85), farai(72), Rudo(91), Chipo(72), Anesu(60)]
by name       : [Anesu(60), Chipo(72), farai(72), Rudo(91), Tariro(85)]
by marks asc  : [Anesu(60), Chipo(72), farai(72), Tariro(85), Rudo(91)]
by marks desc : [Rudo(91), Tariro(85), farai(72), Chipo(72), Anesu(60)]
lambda version: [Anesu(60), Chipo(72), farai(72), Tariro(85), Rudo(91)]
```

`Comparable` defines the class's single **natural ordering** from *inside* the class (`compareTo`, here by name ignoring case), used by `Collections.sort(list)`. A `Comparator` is a separate object that defines **another** ordering from *outside*, so you can have as many as you like (`MarksComparator`, its `.reversed()` form, and the one-line `Comparator.comparingInt(...)` lambda give the same result). Ties in marks (Chipo and farai both 72) are broken by name so the order is deterministic.

## Exercise 6.5 (Challenge)

**Task:** Two interfaces both declare a default void hello(). Write a class that implements both, resolve the conflict with InterfaceName.super.hello(), and explain the rule.

**Files:** Greeter.java, Welcomer.java, Receptionist.java, DefaultConflictDemo.java, ClassWinsDemo.java, does-not-compile/Receptionist_FAILS.java.txt

**Run:** `java DefaultConflictDemo`

**Output**

```
Hello from Greeter
Welcome from Welcomer
Hello from Receptionist itself
```

**The rule.** When a class inherits a method with the same signature from several places Java decides in this order: (1) a method from a **class** (the class itself or a superclass) always wins over an interface default (`ClassWinsDemo` shows `Parent.hello()` beating `Greeter.hello()`); (2) otherwise the **most specific interface** wins (a sub-interface that overrides a default beats its parent); (3) if two **unrelated** interfaces still conflict, the compiler refuses to guess and the class **must override** the method itself. Inside that override, `InterfaceName.super.hello()` calls a chosen interface's version explicitly.

Without the override, the real compiler error is:

```
Receptionist.java:4: error: types Greeter and Welcomer are incompatible;
public class Receptionist implements Greeter, Welcomer {
       ^
  class Receptionist inherits unrelated defaults for hello() from types Greeter and Welcomer
1 error
```

`Receptionist` fixes this by overriding `hello()` and calling `Greeter.super.hello()` and `Welcomer.super.hello()`, as shown in the output above.

