# Lab 6: Abstraction, Abstract Classes and Interfaces: Exercises

Solutions to the exercises at the end of Lab 6 of the *Object-Oriented Programming in Java* lab manual.
Requires **JDK 17 or later**. Every file is in the default package, as in the manual.

| Exercise | Level | Files |
| --- | --- | --- |
| 6.1 | Basic | Shape.java, Circle.java, Rectangle.java, Square.java, ShapeDemo.java |
| 6.2 | Basic | Flyable.java, Bird.java, Aeroplane.java, FlyableDemo.java |
| 6.3 | Intermediate | Account.java, SavingsAccount.java, CurrentAccount.java, AccountDemo.java |
| 6.4 | Intermediate | Student.java, MarksComparator.java, StudentSortDemo.java |
| 6.5 | Challenge | Greeter.java, Welcomer.java, Receptionist.java, DefaultConflictDemo.java, ClassWinsDemo.java, does-not-compile/Receptionist_FAILS.java.txt |

The folder `does-not-compile/` (outside `src`) holds the deliberately broken `Receptionist` for Exercise 6.5, as a `.txt` file so it cannot break the build.

**`LAB_RECORD.md` contains the task, output and written explanations for every exercise** (copy these into your lab record).

## Open in VS Code

1. Install the **Extension Pack for Java** if VS Code offers it.
2. **File > Open Folder...** and choose the folder that directly contains `src` and `.vscode`
   (if unzipping created a folder inside a folder, open the inner one).
3. Open a `*Demo.java` file and click **Run** above `main` (the Code Runner extension also works).
   Classes without a `main` method are helpers and cannot be run on their own.


## Run from a terminal

```
cd src
javac *.java
java ShapeDemo
```

Replace the class name with the program you want to run (see the table in `LAB_RECORD.md`).
