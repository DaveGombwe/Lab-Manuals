public class AccountDemo {
    public static void main(String[] args) {
        Account[] accounts = {
            new SavingsAccount("SAV-001", "Tariro", 1500.00),
            new SavingsAccount("SAV-002", "Farai", 400.00),
            new CurrentAccount("CUR-001", "Rudo", 800.00)
        };

        System.out.println("--- before ---");
        for (Account a : accounts) System.out.println(a);

        accounts[1].deposit(700.00);          // inherited concrete method; Farai now has 1100
        System.out.println();
        System.out.println("--- after Farai deposits 700 ---");
        for (Account a : accounts) System.out.println(a);

        for (Account a : accounts) a.applyMonthlyFee();
        System.out.println();
        System.out.println("--- after the monthly fee ---");
        for (Account a : accounts) System.out.println(a);
    }
}
