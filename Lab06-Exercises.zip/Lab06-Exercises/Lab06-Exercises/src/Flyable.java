// Exercise 6.2 (Basic): an interface is a CAPABILITY that unrelated classes can share
public interface Flyable {
    void fly();
}
