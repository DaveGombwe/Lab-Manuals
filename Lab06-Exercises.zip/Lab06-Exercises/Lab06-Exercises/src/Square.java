// A square is a rectangle whose sides are equal, so it reuses Rectangle completely
public class Square extends Rectangle {
    public Square(double side) {
        super(side, side);
    }
}
