public class Aeroplane implements Flyable {
    private final String model;

    public Aeroplane(String model) { this.model = model; }

    @Override
    public void fly() {
        System.out.println("The " + model + " accelerates down the runway and takes off");
    }
}
