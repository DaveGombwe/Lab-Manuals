public class CurrentAccount extends Account {

    public CurrentAccount(String accountNumber, String owner, double openingBalance) {
        super(accountNumber, owner, openingBalance);
    }

    // Flat fee regardless of balance
    @Override
    public double monthlyFee() {
        return 15.0;
    }
}
