// Exercise 6.5 (Challenge): two interfaces that declare the SAME default method
public interface Greeter {
    default void hello() {
        System.out.println("Hello from Greeter");
    }
}
