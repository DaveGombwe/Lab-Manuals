// Companion to Exercise 6.5: the "class wins" rule.
// If a SUPERCLASS provides hello(), that method beats an interface's default method.
class Parent {
    public void hello() {
        System.out.println("Hello from the Parent CLASS");
    }
}

class Child extends Parent implements Greeter {
    // No override needed: Parent.hello() wins over Greeter.hello()
}

public class ClassWinsDemo {
    public static void main(String[] args) {
        new Child().hello();
    }
}
