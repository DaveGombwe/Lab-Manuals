import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class StudentSortDemo {
    public static void main(String[] args) {
        List<Student> list = new ArrayList<>(List.of(
            new Student("Tariro", 85),
            new Student("farai", 72),
            new Student("Rudo", 91),
            new Student("Chipo", 72),
            new Student("Anesu", 60)
        ));
        System.out.println("original      : " + list);

        Collections.sort(list);                              // uses Comparable (compareTo)
        System.out.println("by name       : " + list);

        list.sort(new MarksComparator());                    // uses the Comparator class
        System.out.println("by marks asc  : " + list);

        list.sort(new MarksComparator().reversed());         // reversed(): highest first
        System.out.println("by marks desc : " + list);

        // The same ordering written as a one-line comparator instead of a class
        list.sort(Comparator.comparingInt(Student::getMarks).thenComparing(Student::getName));
        System.out.println("lambda version: " + list);
    }
}
