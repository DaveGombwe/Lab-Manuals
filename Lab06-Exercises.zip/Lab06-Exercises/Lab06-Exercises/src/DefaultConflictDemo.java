public class DefaultConflictDemo {
    public static void main(String[] args) {
        new Receptionist().hello();
    }
}
