// Exercise 6.4 (Intermediate): natural ordering by NAME via Comparable
public class Student implements Comparable<Student> {
    private final String name;
    private final int marks;

    public Student(String name, int marks) {
        this.name = name;
        this.marks = marks;
    }

    public String getName() { return name; }
    public int getMarks()   { return marks; }

    // EXPLAIN: negative = this comes first, zero = equal, positive = this comes after other
    @Override
    public int compareTo(Student other) {
        return name.compareToIgnoreCase(other.name);
    }

    @Override
    public String toString() {
        return name + "(" + marks + ")";
    }
}
