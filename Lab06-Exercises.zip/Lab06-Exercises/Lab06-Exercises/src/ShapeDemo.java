public class ShapeDemo {
    public static void main(String[] args) {
        // Shape s = new Shape();     // COMPILE ERROR: Shape is abstract and cannot be instantiated

        Shape[] shapes = { new Circle(5), new Rectangle(4, 6), new Square(3) };

        double totalArea = 0;
        for (Shape s : shapes) {
            System.out.println(s.describe());
            totalArea += s.area();
        }
        System.out.printf("Total area: %.2f%n", totalArea);
    }
}
