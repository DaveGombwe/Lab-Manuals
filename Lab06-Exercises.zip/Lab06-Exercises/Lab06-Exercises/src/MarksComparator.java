import java.util.Comparator;

// Exercise 6.4: a SEPARATE ordering by marks, ascending; ties are broken by name
public class MarksComparator implements Comparator<Student> {
    @Override
    public int compare(Student a, Student b) {
        int byMarks = Integer.compare(a.getMarks(), b.getMarks());
        return byMarks != 0 ? byMarks : a.compareTo(b);
    }
}
