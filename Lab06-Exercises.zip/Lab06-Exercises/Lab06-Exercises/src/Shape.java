// Exercise 6.1 (Basic): an abstract class declares WHAT every shape can do, not HOW
public abstract class Shape {

    public abstract double area();         // no body: every concrete subclass must implement it
    public abstract double perimeter();

    // A concrete (implemented) method that reuses the abstract ones
    public String describe() {
        return String.format("%-9s area=%8.2f perimeter=%8.2f",
                getClass().getSimpleName(), area(), perimeter());
    }
}
