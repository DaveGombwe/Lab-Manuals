public class FlyableDemo {
    public static void main(String[] args) {
        Flyable[] fliers = { new Bird("eagle"), new Aeroplane("Boeing 737"), new Bird("swallow") };
        for (Flyable f : fliers) {
            f.fly();
        }

        // Bird and Aeroplane share NO superclass of their own: both extend only Object
        System.out.println("Bird's superclass:      " + Bird.class.getSuperclass().getSimpleName());
        System.out.println("Aeroplane's superclass: " + Aeroplane.class.getSuperclass().getSimpleName());
    }
}
