public class SavingsAccount extends Account {

    private static final double MIN_BALANCE_FOR_FREE = 1000.0;

    public SavingsAccount(String accountNumber, String owner, double openingBalance) {
        super(accountNumber, owner, openingBalance);
    }

    // Free when the balance is at least 1000, otherwise a small fee
    @Override
    public double monthlyFee() {
        return getBalance() >= MIN_BALANCE_FOR_FREE ? 0.0 : 5.0;
    }
}
