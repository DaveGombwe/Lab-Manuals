public interface Welcomer {
    default void hello() {
        System.out.println("Welcome from Welcomer");
    }
}
