// Implements BOTH interfaces. javac refuses to guess which hello() to inherit, so the class must
// override hello() itself, and may reuse either parent with  InterfaceName.super.hello().
public class Receptionist implements Greeter, Welcomer {

    @Override
    public void hello() {
        Greeter.super.hello();        // explicitly choose Greeter's version
        Welcomer.super.hello();       // and Welcomer's version
        System.out.println("Hello from Receptionist itself");
    }
}
