// Exercise 6.3 (Intermediate): shared state and behaviour in the abstract class,
// the part that differs per account type left abstract.
public abstract class Account {
    private final String accountNumber;
    private final String owner;
    private double balance;

    protected Account(String accountNumber, String owner, double openingBalance) {
        if (openingBalance < 0) throw new IllegalArgumentException("Opening balance cannot be negative");
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.balance = openingBalance;
    }

    public String getAccountNumber() { return accountNumber; }
    public double getBalance()       { return balance; }

    // CONCRETE: identical for every account type
    public void deposit(double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive");
        balance += amount;
    }

    // ABSTRACT: each account type decides its own fee
    public abstract double monthlyFee();

    // CONCRETE method that CALLS the abstract one (the "template method" idea)
    public void applyMonthlyFee() {
        balance -= monthlyFee();
    }

    @Override
    public String toString() {
        return String.format("%-14s %s [%s] balance: %9.2f  monthly fee: %6.2f",
                getClass().getSimpleName(), accountNumber, owner, balance, monthlyFee());
    }
}
