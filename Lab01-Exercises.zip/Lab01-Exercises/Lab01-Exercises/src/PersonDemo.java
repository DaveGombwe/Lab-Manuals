// Exercise 1.5: chained dot expression, and what happens when the address is null
public class PersonDemo {
    public static void main(String[] args) {
        // Person WITH an address
        Address a = new Address();
        a.street = "12 Samora Machel Avenue";
        a.city = "Harare";

        Person p1 = new Person();
        p1.name = "Tariro";
        p1.address = a;

        // EXPLAIN: person -> address -> city, one dot per hop
        System.out.println(p1.name + " lives in " + p1.address.city);

        // Person WITHOUT an address: the field was never assigned, so it is null
        Person p2 = new Person();
        p2.name = "Farai";
        System.out.println("p2.address is null? " + (p2.address == null));

        // The chained expression fails because null has no 'city' to read
        try {
            System.out.println(p2.name + " lives in " + p2.address.city);
        } catch (NullPointerException e) {
            System.out.println("NullPointerException: cannot read city, address is null");
        }

        // The safe way: test for null before following the reference
        if (p2.address != null) {
            System.out.println(p2.name + " lives in " + p2.address.city);
        } else {
            System.out.println(p2.name + " has no address on record");
        }
    }
}
