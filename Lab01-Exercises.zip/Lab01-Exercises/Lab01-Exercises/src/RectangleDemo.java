// Exercise 1.3: array of 5 rectangles, print the one with the largest area
public class RectangleDemo {

    // helper so we do not repeat three assignment lines five times
    static Rectangle make(double w, double h) {
        Rectangle r = new Rectangle();
        r.width = w;
        r.height = h;
        return r;
    }

    public static void main(String[] args) {
        // EXPLAIN: new Rectangle[5] creates 5 EMPTY slots (all null); each slot is then filled
        Rectangle[] rects = new Rectangle[5];
        rects[0] = make(3, 4);
        rects[1] = make(5, 2);
        rects[2] = make(6, 7);
        rects[3] = make(2, 2);
        rects[4] = make(10, 1);

        for (Rectangle r : rects) {
            r.display();
        }

        // EXPLAIN: 'largest' holds a REFERENCE to the best rectangle so far (no copying)
        Rectangle largest = rects[0];
        for (Rectangle r : rects) {
            if (r.area() > largest.area()) {
                largest = r;
            }
        }
        System.out.println("Largest area:");
        largest.display();
    }
}
