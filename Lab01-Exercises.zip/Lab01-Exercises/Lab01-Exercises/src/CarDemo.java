// Exercises 1.1 and 1.2: create three cars, print them, and test isAntique()
public class CarDemo {
    public static void main(String[] args) {
        Car c1 = new Car();
        c1.brand = "Toyota";
        c1.year = 2015;
        c1.mileage = 98500.5;

        Car c2 = new Car();
        c2.brand = "Ford";
        c2.year = 1975;
        c2.mileage = 154300.0;

        Car c3 = new Car();
        c3.brand = "Honda";
        c3.year = 2020;
        c3.mileage = 42000.0;

        Car[] cars = {c1, c2, c3};
        for (Car c : cars) {
            c.display();
            System.out.println("   antique? " + c.isAntique());
        }
    }
}
