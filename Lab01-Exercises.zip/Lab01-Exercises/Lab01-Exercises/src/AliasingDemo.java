// Exercise 1.4 (Intermediate): predict, then run.
//
// PREDICTION (written BEFORE running):
//   r2 = r1 copies the reference, so r1 and r2 point to ONE Rectangle object.
//   Changing r2.width therefore changes r1.width too.
//   I predict that the program prints 10.0 for r1.width, not 5.0.
public class AliasingDemo {
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle();
        r1.width = 5;
        r1.height = 3;

        Rectangle r2 = r1;        // alias: same object, two names
        r2.width = 10;

        System.out.println("r1.width = " + r1.width);   // 10.0
        System.out.println("r1 == r2 ? " + (r1 == r2)); // true: same object

        // For contrast: a real, independent copy (field by field)
        Rectangle r3 = new Rectangle();
        r3.width = r1.width;
        r3.height = r1.height;
        r3.width = 99;            // changes ONLY r3

        System.out.println("After changing the copy r3.width to 99:");
        System.out.println("r1.width = " + r1.width + ", r3.width = " + r3.width);
        System.out.println("r1 == r3 ? " + (r1 == r3));  // false: different objects
    }
}
