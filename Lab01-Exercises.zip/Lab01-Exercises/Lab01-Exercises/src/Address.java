// Exercise 1.5 (Challenge)
public class Address {
    String street;
    String city;
}
