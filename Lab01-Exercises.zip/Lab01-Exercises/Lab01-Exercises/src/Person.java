// Exercise 1.5 (Challenge): a Person HAS an Address (a field that is a reference)
public class Person {
    String name;
    Address address;     // stays null until we assign an Address object
}
