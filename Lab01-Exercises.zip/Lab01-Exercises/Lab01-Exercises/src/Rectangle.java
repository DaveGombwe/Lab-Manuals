// Exercise 1.3 (Intermediate)
public class Rectangle {
    double width;
    double height;

    double area() {
        return width * height;
    }

    double perimeter() {
        return 2 * (width + height);
    }

    void display() {
        System.out.printf("Rectangle %.1f x %.1f  area=%.1f  perimeter=%.1f%n",
                width, height, area(), perimeter());
    }
}
