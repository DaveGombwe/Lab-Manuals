import java.time.Year;

// Exercise 1.1 (Basic) and 1.2 (Basic)
public class Car {

    // EXPLAIN: three fields = the STATE of every Car object
    String brand;
    int year;
    double mileage;      // kilometres driven

    // EXPLAIN: an instance method that reads this object's own fields
    void display() {
        System.out.printf("Brand: %s, Year: %d, Mileage: %.1f km%n", brand, year, mileage);
    }

    // Exercise 1.2: true when the car is MORE than 25 years old
    boolean isAntique() {
        int age = Year.now().getValue() - year;   // EXPLAIN: age is calculated, not stored
        return age > 25;
    }
}
