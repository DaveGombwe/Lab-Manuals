# Lab 1: Classes and Objects: Exercises

## Lab record

Solutions to the five exercises at the end of Lab 1. All output below was produced by actually running the programs (JDK 21).

| # | Level | Files | Run |
| --- | --- | --- | --- |
| 1.1 | Basic | Car.java, CarDemo.java | `java CarDemo` |
| 1.2 | Basic | Car.java, CarDemo.java | `java CarDemo` |
| 1.3 | Intermediate | Rectangle.java, RectangleDemo.java | `java RectangleDemo` |
| 1.4 | Intermediate | AliasingDemo.java | `java AliasingDemo` |
| 1.5 | Challenge | Address.java, Person.java, PersonDemo.java | `java PersonDemo` |

## Exercise 1.1 (Basic)

**Task:** Create a Car class with fields brand, year and mileage, and a method display(). Create three cars and print them.

**Files:** Car.java, CarDemo.java

**Run:** `java CarDemo`

**Output**

```
Brand: Toyota, Year: 2015, Mileage: 98500.5 km
   antique? false
Brand: Ford, Year: 1975, Mileage: 154300.0 km
   antique? true
Brand: Honda, Year: 2020, Mileage: 42000.0 km
   antique? false
```

`Car` declares the state (three fields) and behaviour (`display()`). `CarDemo` creates three separate objects with `new`, each holding its own values. The car's age is not stored; it is computed from `Year.now()` when `isAntique()` is called (see 1.2).

## Exercise 1.2 (Basic)

**Task:** Add a method isAntique() to Car that returns true when the car is more than 25 years old.

**Files:** Car.java, CarDemo.java

**Run:** `java CarDemo`

**Output**

```
Brand: Toyota, Year: 2015, Mileage: 98500.5 km
   antique? false
Brand: Ford, Year: 1975, Mileage: 154300.0 km
   antique? true
Brand: Honda, Year: 2020, Mileage: 42000.0 km
   antique? false
```

`isAntique()` returns `Year.now().getValue() - year > 25`. It is computed from the current year, so the 2015 and 2020 cars are not antique and the 1975 car is. The 2015 car becomes antique in 2041.

## Exercise 1.3 (Intermediate)

**Task:** Write a Rectangle class with width, height, and methods area() and perimeter(). Create an array of 5 rectangles and print the one with the largest area.

**Files:** Rectangle.java, RectangleDemo.java

**Run:** `java RectangleDemo`

**Output**

```
Rectangle 3.0 x 4.0  area=12.0  perimeter=14.0
Rectangle 5.0 x 2.0  area=10.0  perimeter=14.0
Rectangle 6.0 x 7.0  area=42.0  perimeter=26.0
Rectangle 2.0 x 2.0  area=4.0  perimeter=8.0
Rectangle 10.0 x 1.0  area=10.0  perimeter=22.0
Largest area:
Rectangle 6.0 x 7.0  area=42.0  perimeter=26.0
```

`new Rectangle[5]` creates five empty slots (all `null`), so each slot is filled with its own object before use. The variable `largest` stores a reference to the best rectangle found so far, so no object is copied. Largest is 6 x 7 with area 42.

## Exercise 1.4 (Intermediate)

**Task:** Predict, then run, a program that assigns Rectangle r2 = r1;, changes r2.width, and prints r1.width. Explain the result in your lab record.

**Files:** AliasingDemo.java

**Run:** `java AliasingDemo`

**Output**

```
r1.width = 10.0
r1 == r2 ? true
After changing the copy r3.width to 99:
r1.width = 10.0, r3.width = 99.0
r1 == r3 ? false
```

**Prediction:** r1.width prints 10.0, not 5.0.

**Explanation:** `Rectangle r2 = r1;` does not copy the rectangle. It copies the reference (the address), so `r1` and `r2` are two names for one object on the heap. Changing `r2.width` therefore changes what `r1` sees, and `r1 == r2` is `true`. The program also builds a real copy `r3` field by field; changing `r3.width` leaves `r1` alone and `r1 == r3` is `false`. To get an independent copy, create a new object and copy the values (copy constructors arrive in Lab 2).

## Exercise 1.5 (Challenge)

**Task:** Create Address and Person classes where a Person has an Address. Print a person's city using a chained dot expression, and show what happens when the address is null.

**Files:** Address.java, Person.java, PersonDemo.java

**Run:** `java PersonDemo`

**Output**

```
Tariro lives in Harare
p2.address is null? true
NullPointerException: cannot read city, address is null
Farai has no address on record
```

`p1.address.city` follows two references: person, then address, then city. For `p2` the `address` field was never assigned, so it holds `null`, and `p2.address.city` throws `NullPointerException` because `null` has no `city` field. Always test `address != null` before following the reference. (A try/catch is used here only to demonstrate the failure; real code should use the null check.)

