# Lab 1: Classes and Objects: Exercises

Solutions to the exercises at the end of Lab 1 of the *Object-Oriented Programming in Java* lab manual.
Requires **JDK 17 or later**. Every file is in the default package, as in the manual.

| Exercise | Level | Files |
| --- | --- | --- |
| 1.1 | Basic | Car.java, CarDemo.java |
| 1.2 | Basic | Car.java, CarDemo.java |
| 1.3 | Intermediate | Rectangle.java, RectangleDemo.java |
| 1.4 | Intermediate | AliasingDemo.java |
| 1.5 | Challenge | Address.java, Person.java, PersonDemo.java |

**`LAB_RECORD.md` contains the task, output and written explanations for every exercise** (copy these into your lab record).

## Open in VS Code

1. Install the **Extension Pack for Java** if VS Code offers it.
2. **File > Open Folder...** and choose the folder that directly contains `src` and `.vscode`
   (if unzipping created a folder inside a folder, open the inner one).
3. Open a `*Demo.java` file (or `TwoBlocks.java` in Lab 2) and click **Run** above `main`.
   The Code Runner extension also works.

## Run from a terminal

```
cd src
javac *.java
java CarDemo
```

Replace the class name with the demo you want to run (see the table in `LAB_RECORD.md`). Classes without a `main` method (for example `Car`) are helpers and cannot be run on their own.
