# Lab 5: Polymorphism: Exercises

## Lab record

Solutions to the five exercises at the end of Lab 5. All output below was produced by actually running the programs (JDK 21).

| # | Level | Files | Run |
| --- | --- | --- | --- |
| 5.1 | Basic | Printer.java, PrinterDemo.java | `java PrinterDemo` |
| 5.2 | Basic | Animal.java, Cat.java, Cow.java, Duck.java, AnimalDemo.java | `java AnimalDemo` |
| 5.3 | Intermediate | Employee.java, Manager.java, Developer.java, Intern.java, Payroll.java, PayrollDemo.java | `java PayrollDemo` |
| 5.4 | Intermediate | Parent.java, Child.java, FieldVsMethodDemo.java | `java FieldVsMethodDemo` |
| 5.5 | Challenge | Payment.java, CardPayment.java, MobileMoneyPayment.java, BankTransferPayment.java, PaymentProcessorV1.java, PaymentProcessorV2.java, PaymentDemo.java | `java PaymentDemo` |

## Exercise 5.1 (Basic)

**Task:** Overload a print method to accept int, double, String and int[], and test each call.

**Files:** Printer.java, PrinterDemo.java

**Run:** `java PrinterDemo`

**Output**

```
int: 42
double: 3.14
String: Hello
int[]: [1, 2, 3]
int: 65
double: 7.0
```

Four overloads share the name `print`; the **compiler** chooses one from the static types of the arguments (compile-time polymorphism). When there is no exact match it applies widening: `'A'` (char) becomes `int`, so it prints 65, and `7L` (long) becomes `double`, so it prints 7.0. Return type alone cannot distinguish overloads, and `print(null)` would not compile because `String` and `int[]` both accept `null` (ambiguous).

## Exercise 5.2 (Basic)

**Task:** Create Animal with sound() and subclasses Cat, Cow, Duck. Store them in an Animal[] and loop.

**Files:** Animal.java, Cat.java, Cow.java, Duck.java, AnimalDemo.java

**Run:** `java AnimalDemo`

**Output**

```
Tom says Meow
Daisy says Moo
Donald says Quack
Mystery animal says ...
```

The array's declared type is `Animal`, but each slot holds a `Cat`, `Cow`, `Duck` or plain `Animal` (upcasting). In the loop `a.sound()` is resolved at **run time** from the real object (dynamic method dispatch), so one line of code gives four different behaviours.

## Exercise 5.3 (Intermediate)

**Task:** Extend the employee hierarchy of Lab 4 with Intern. Compute total payroll for a mixed array without changing the payroll loop.

**Files:** Employee.java, Manager.java, Developer.java, Intern.java, Payroll.java, PayrollDemo.java

**Run:** `java PayrollDemo`

**Output**

```
--- before Intern existed ---
Kudzai   Employee   earns  2000.00
Nyasha   Manager    earns  4300.00
Tatenda  Developer  earns  3250.00
Total payroll: 9550.00

--- after adding two interns ---
Kudzai   Employee   earns  2000.00
Nyasha   Manager    earns  4300.00
Tatenda  Developer  earns  3250.00
Ruvimbo  Intern     earns   700.00
Kuda     Intern     earns   750.00
Total payroll: 11000.00
```

`Payroll.totalPayroll` loops over `Employee[]` and calls `calculatePay()`. Adding `Intern` (stipend + 100 transport allowance) required **no change** to `Payroll`: the second run uses the identical loop and simply gets two `Intern` objects in the array. This is the open/closed idea: open for extension (new subclass), closed for modification (existing loop untouched). The Lab 4 constructor trace messages were removed so the output stays readable.

## Exercise 5.4 (Intermediate)

**Task:** Write a program whose output differs depending on whether a method or a field is accessed through a superclass reference, and explain why.

**Files:** Parent.java, Child.java, FieldVsMethodDemo.java

**Run:** `java FieldVsMethodDemo`

**Output**

```
p.who()          = Child method
p.name           = Parent field
((Child) p).name = Child field
Parent.kind()    = Parent static method
Child.kind()     = Child static method
```

**Prediction (also in the file header):** `p.who()` gives the Child version, `p.name` gives the Parent field, `((Child) p).name` gives the Child field.

**Explanation:** instance **methods** are dispatched at run time on the object's real class, so `Parent p = new Child(); p.who()` runs `Child.who()`. **Fields** are not polymorphic: a field access is fixed by the compiler from the variable's *declared* type, so `p.name` reads `Parent.name` even though the object is a `Child`. `Child.name` merely *hides* the parent's field (the object holds both). Static methods behave like fields here (resolved from the declared type). The practical rule: keep fields `private` and expose behaviour through methods, so the polymorphic version is always the one used.

## Exercise 5.5 (Challenge)

**Task:** Implement a small PaymentProcessor.pay(Payment p) that uses instanceof pattern matching for CardPayment and MobileMoneyPayment. Then refactor it to use a polymorphic process() method and compare the two designs.

**Files:** Payment.java, CardPayment.java, MobileMoneyPayment.java, BankTransferPayment.java, PaymentProcessorV1.java, PaymentProcessorV2.java, PaymentDemo.java

**Run:** `java PaymentDemo`

**Output**

```
=== Design 1: instanceof ===
[V1] Charging card ****1234 for 150.00
[V1] Mobile-money request to +263771234567 for 40.50
[V1] FAILED at run time: Unsupported payment type: BankTransferPayment

=== Design 2: polymorphic process() ===
[V2] Charging card ****1234 for 150.00
[V2] Mobile-money request to +263771234567 for 40.50
[V2] Bank transfer to account 0012-3456 for 900.00
```

`PaymentProcessorV1` (design 1) tests the type with `instanceof` pattern matching (`p instanceof CardPayment c` tests and casts in one step). `PaymentProcessorV2` (design 2, the refactoring) is one line: `p.process()`, with each payment class owning its own behaviour. Both processors are kept so you can run them side by side; `BankTransferPayment` was added afterwards to compare them. (`Payment` is declared `abstract` so every subclass must supply `process()`; abstract classes are covered properly in Lab 6.)

| | Design 1: `instanceof` | Design 2: polymorphic `process()` |
| --- | --- | --- |
| Adding a new payment type | Edit the processor (new `else if` branch) | Add one new class; processor untouched |
| Forgetting to handle a type | Fails at **run time** (the demo shows the exception for bank transfer) | Impossible: the compiler forces `process()` to be implemented |
| Where the logic lives | In one place, away from the data | Inside each payment class, next to its data |
| Coupling | Processor knows every concrete class | Processor knows only `Payment` |
| Open/closed principle | Violated | Respected |
| Good use | Types you cannot change (library or `sealed` types) or logic that truly belongs outside the data class | Default choice when you own the classes |

Conclusion: design 2 is the better object-oriented design because the *object* decides what to do; `instanceof` chains are a warning sign that behaviour is in the wrong class.

