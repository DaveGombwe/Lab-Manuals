public class Child extends Parent {
    String name = "Child field";          // HIDES Parent.name (does not override it)

    @Override
    String who() {                        // OVERRIDES Parent.who()
        return "Child method";
    }

    static String kind() {                // HIDES Parent.kind() (static methods are not overridden)
        return "Child static method";
    }
}
