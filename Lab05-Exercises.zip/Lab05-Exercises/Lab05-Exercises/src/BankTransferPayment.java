// Added LATER to compare the two designs: neither processor was written with this class in mind
public class BankTransferPayment extends Payment {
    private final String accountNumber;

    public BankTransferPayment(String accountNumber, double amount) {
        super(amount);
        this.accountNumber = accountNumber;
    }

    @Override
    public void process() {
        System.out.printf("[V2] Bank transfer to account %s for %.2f%n", accountNumber, getAmount());
    }
}
