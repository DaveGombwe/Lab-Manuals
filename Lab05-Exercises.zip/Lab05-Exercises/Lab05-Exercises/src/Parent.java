// Exercise 5.4: a field, an instance method and a static method, all redefined in Child
public class Parent {
    String name = "Parent field";

    String who() {
        return "Parent method";
    }

    static String kind() {
        return "Parent static method";
    }
}
