// Exercise 5.2 (Basic): superclass with a method that subclasses override
public class Animal {
    protected final String name;

    public Animal(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    // Default behaviour; subclasses replace it
    public String sound() {
        return "...";
    }
}
