// Exercise 5.1 (Basic): method OVERLOADING = compile-time polymorphism.
// Same name, different parameter lists; the COMPILER picks the version from the argument types.
public class Printer {

    public void print(int n)     { System.out.println("int: " + n); }
    public void print(double d)  { System.out.println("double: " + d); }
    public void print(String s)  { System.out.println("String: " + s); }
    public void print(int[] a)   { System.out.println("int[]: " + java.util.Arrays.toString(a)); }
}
