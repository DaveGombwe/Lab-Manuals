// Exercise 5.3: this loop is written ONCE and never edited when new Employee types appear.
public class Payroll {

    public static double totalPayroll(Employee[] staff) {
        double total = 0;
        for (Employee e : staff) {
            total += e.calculatePay();     // dynamic dispatch picks the right calculatePay()
        }
        return total;
    }
}
