// Exercise 5.5 (Challenge): common type for all payments.
// 'abstract' is formally taught in Lab 6; here it only means "every subclass must supply process()".
public abstract class Payment {
    private final double amount;

    protected Payment(double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }
        this.amount = amount;
    }

    public double getAmount() { return amount; }

    // Used by design 2 (polymorphic). Design 1 ignores it and uses instanceof instead.
    public abstract void process();
}
