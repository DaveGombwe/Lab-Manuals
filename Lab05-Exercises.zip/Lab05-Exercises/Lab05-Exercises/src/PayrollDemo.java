// Exercise 5.3: compute the payroll of a mixed array, before and after adding Intern
public class PayrollDemo {
    public static void main(String[] args) {
        Employee[] before = {
            new Employee("Kudzai", 2000),
            new Manager("Nyasha", 3500, 800),
            new Developer("Tatenda", 3000, 10)
        };
        System.out.println("--- before Intern existed ---");
        for (Employee e : before) e.describe();
        System.out.printf("Total payroll: %.2f%n", Payroll.totalPayroll(before));

        // Same Payroll class, same loop. Only the array contents changed.
        Employee[] after = {
            new Employee("Kudzai", 2000),
            new Manager("Nyasha", 3500, 800),
            new Developer("Tatenda", 3000, 10),
            new Intern("Ruvimbo", 600),
            new Intern("Kuda", 650)
        };
        System.out.println();
        System.out.println("--- after adding two interns ---");
        for (Employee e : after) e.describe();
        System.out.printf("Total payroll: %.2f%n", Payroll.totalPayroll(after));
    }
}
