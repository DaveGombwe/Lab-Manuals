// Design 2 (after refactoring): tell the object to process itself; polymorphism does the rest
public class PaymentProcessorV2 {

    public void pay(Payment p) {
        p.process();
    }
}
