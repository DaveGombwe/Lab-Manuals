// Design 1: ask "what type are you?" with instanceof pattern matching
public class PaymentProcessorV1 {

    public void pay(Payment p) {
        if (p instanceof CardPayment c) {                  // EXPLAIN: test AND cast in one step
            System.out.printf("[V1] Charging card %s for %.2f%n", c.maskedNumber(), c.getAmount());
        } else if (p instanceof MobileMoneyPayment m) {
            System.out.printf("[V1] Mobile-money request to %s for %.2f%n", m.getPhone(), m.getAmount());
        } else {
            // Every NEW payment type must be added above, or it ends up here at RUN time
            throw new IllegalArgumentException("Unsupported payment type: " + p.getClass().getSimpleName());
        }
    }
}
