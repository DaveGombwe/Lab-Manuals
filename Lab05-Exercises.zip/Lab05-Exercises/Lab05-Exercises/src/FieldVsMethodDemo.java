// Exercise 5.4: output depends on whether a FIELD or a METHOD is used through a superclass reference
//
// PREDICTION (written BEFORE running), for  Parent p = new Child();
//   p.who()        -> "Child method"        (instance methods follow the REAL object)
//   p.name         -> "Parent field"        (fields follow the DECLARED type of the variable)
//   ((Child) p).name -> "Child field"       (the cast changes the declared type)
//   Parent.kind()/p.kind() -> "Parent static method"  (static methods follow the declared type)
public class FieldVsMethodDemo {
    public static void main(String[] args) {
        Parent p = new Child();     // declared type: Parent, real object: Child

        System.out.println("p.who()          = " + p.who());
        System.out.println("p.name           = " + p.name);
        System.out.println("((Child) p).name = " + ((Child) p).name);
        System.out.println("Parent.kind()    = " + Parent.kind());
        System.out.println("Child.kind()     = " + Child.kind());
    }
}
