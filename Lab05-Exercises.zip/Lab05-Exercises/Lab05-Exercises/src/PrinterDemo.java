// Exercise 5.1: test each overload, plus two calls that rely on automatic widening
public class PrinterDemo {
    public static void main(String[] args) {
        Printer p = new Printer();

        p.print(42);                       // exact match: print(int)
        p.print(3.14);                     // exact match: print(double)
        p.print("Hello");                  // exact match: print(String)
        p.print(new int[] {1, 2, 3});      // exact match: print(int[])

        // No exact match, so the compiler widens the argument to the closest overload:
        p.print('A');                      // char -> int      => print(int) prints 65
        p.print(7L);                       // long -> double   => print(double) prints 7.0

        // p.print(null);                  // COMPILE ERROR: ambiguous (String and int[] both accept null)
    }
}
