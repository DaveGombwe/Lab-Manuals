// Exercise 5.2: one Animal[] holding different subclasses; one loop; different behaviour
public class AnimalDemo {
    public static void main(String[] args) {
        // EXPLAIN: upcasting - every element is stored as an Animal reference
        Animal[] zoo = {
            new Cat("Tom"),
            new Cow("Daisy"),
            new Duck("Donald"),
            new Animal("Mystery animal")
        };

        for (Animal a : zoo) {
            // EXPLAIN: the JVM looks at the REAL object, not the Animal variable (dynamic dispatch)
            System.out.println(a.getName() + " says " + a.sound());
        }
    }
}
