public class CardPayment extends Payment {
    private final String cardNumber;

    public CardPayment(String cardNumber, double amount) {
        super(amount);
        this.cardNumber = cardNumber;
    }

    public String maskedNumber() {
        return "****" + cardNumber.substring(cardNumber.length() - 4);
    }

    @Override
    public void process() {
        System.out.printf("[V2] Charging card %s for %.2f%n", maskedNumber(), getAmount());
    }
}
