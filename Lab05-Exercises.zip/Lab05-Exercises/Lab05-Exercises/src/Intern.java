// Exercise 5.3: the NEW subclass. Nothing else in the project has to change.
public class Intern extends Employee {

    private static final double TRANSPORT_ALLOWANCE = 100.0;

    // baseSalary here is the monthly stipend
    public Intern(String name, double stipend) {
        super(name, stipend);
    }

    @Override
    public double calculatePay() {
        return baseSalary + TRANSPORT_ALLOWANCE;
    }
}
