// Exercise 5.5: compare the two designs side by side
public class PaymentDemo {
    public static void main(String[] args) {
        Payment card   = new CardPayment("4111111111111234", 150.00);
        Payment mobile = new MobileMoneyPayment("+263771234567", 40.50);
        Payment bank   = new BankTransferPayment("0012-3456", 900.00);   // a NEW type

        PaymentProcessorV1 v1 = new PaymentProcessorV1();
        PaymentProcessorV2 v2 = new PaymentProcessorV2();

        System.out.println("=== Design 1: instanceof ===");
        v1.pay(card);
        v1.pay(mobile);
        try {
            v1.pay(bank);                       // V1 was never told about bank transfers
        } catch (IllegalArgumentException e) {
            System.out.println("[V1] FAILED at run time: " + e.getMessage());
        }

        System.out.println();
        System.out.println("=== Design 2: polymorphic process() ===");
        v2.pay(card);
        v2.pay(mobile);
        v2.pay(bank);                           // works with NO change to PaymentProcessorV2
    }
}
