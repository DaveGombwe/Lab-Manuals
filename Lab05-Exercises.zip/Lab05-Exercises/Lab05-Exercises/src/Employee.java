// Exercise 5.3: the Lab 4 hierarchy (constructor trace messages removed to keep the output short)
public class Employee {

    private final String name;
    protected double baseSalary;

    public Employee(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
    }

    public String getName() { return name; }

    public double calculatePay() {
        return baseSalary;
    }

    public void describe() {
        System.out.printf("%-8s %-10s earns %8.2f%n", name, getClass().getSimpleName(), calculatePay());
    }
}
