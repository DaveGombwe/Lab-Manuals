public class MobileMoneyPayment extends Payment {
    private final String phone;

    public MobileMoneyPayment(String phone, double amount) {
        super(amount);
        this.phone = phone;
    }

    public String getPhone() { return phone; }

    @Override
    public void process() {
        System.out.printf("[V2] Mobile-money request to %s for %.2f%n", phone, getAmount());
    }
}
