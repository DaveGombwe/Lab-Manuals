# Lab 5: Polymorphism: Exercises

Solutions to the exercises at the end of Lab 5 of the *Object-Oriented Programming in Java* lab manual.
Requires **JDK 17 or later**. Every file is in the default package, as in the manual.

| Exercise | Level | Files |
| --- | --- | --- |
| 5.1 | Basic | Printer.java, PrinterDemo.java |
| 5.2 | Basic | Animal.java, Cat.java, Cow.java, Duck.java, AnimalDemo.java |
| 5.3 | Intermediate | Employee.java, Manager.java, Developer.java, Intern.java, Payroll.java, PayrollDemo.java |
| 5.4 | Intermediate | Parent.java, Child.java, FieldVsMethodDemo.java |
| 5.5 | Challenge | Payment.java, CardPayment.java, MobileMoneyPayment.java, BankTransferPayment.java, PaymentProcessorV1.java, PaymentProcessorV2.java, PaymentDemo.java |

**`LAB_RECORD.md` contains the task, output and written explanations for every exercise** (copy these into your lab record).

## Open in VS Code

1. Install the **Extension Pack for Java** if VS Code offers it.
2. **File > Open Folder...** and choose the folder that directly contains `src` and `.vscode`
   (if unzipping created a folder inside a folder, open the inner one).
3. Open a `*Demo.java` file and click **Run** above `main` (the Code Runner extension also works).
   Classes without a `main` method are helpers and cannot be run on their own.


## Run from a terminal

```
cd src
javac *.java
java PrinterDemo
```

Replace the class name with the program you want to run (see the table in `LAB_RECORD.md`).
